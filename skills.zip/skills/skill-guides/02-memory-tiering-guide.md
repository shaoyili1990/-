# Skill调用流程说明文档 - memory-tiering

**Skill名称**: memory-tiering  
**版本**: 1.0.0  
**用途**: 记忆分层管理（天道系统核心组件）  
**安装时间**: 2026-04-17  

---

## 一、功能概述

memory-tiering 实现动态三层记忆架构，优化上下文使用和检索效率：
- **🔥 HOT**: 当前会话上下文、活跃任务、临时凭证、即时目标
- **🌡️ WARM**: 用户偏好、核心系统清单、稳定配置、重复兴趣
- **❄️ COLD**: 长期归档、历史决策、项目里程碑、提炼教训

**核心优势**:
- 自动分层管理，减少Token消耗
- 动态调整记忆加载策略
- 与天道系统的"权重驱动记忆加载"完美契合

---

## 二、三层架构详解

### HOT层（热记忆）

**存储位置**: `memory/hot/HOT_MEMORY.md`

**内容**:
- 当前会话中的活跃任务
- 临时凭证和配置
- 即时目标和待办事项
- 最近2-3轮对话的关键信息

**管理策略**:
- 频繁更新
- 任务完成后积极清理
- 保持精简，便于快速加载

### WARM层（温记忆）

**存储位置**: `memory/warm/WARM_MEMORY.md`

**内容**:
- 用户偏好和风格设定
- 核心系统清单和工具
- 稳定配置和参数
- 重复出现的兴趣点

**管理策略**:
- 偏好改变时更新
- 长期保持，但非永久
- 定期审查和整理

### COLD层（冷记忆）

**存储位置**: `MEMORY.md`

**内容**:
- 历史决策和项目里程碑
- 提炼的教训和公理
- 已完成项目的摘要
- 长期归档信息

**管理策略**:
- 归档阶段更新
- 细节被摘要替代
- 永久保存，但精简

---

## 三、调用流程

### 流程1：初始化天道系统记忆架构

**场景**: 启动新的天道世界，需要建立记忆分层

```bash
# 触发记忆分层整理
Run memory tiering

# 或中文
整理记忆层级
```

**执行步骤**:
1. 创建三层存储结构
2. 初始化HOT层：当前世界设定、初始角色参数
3. 初始化WARM层：世界规则、角色类型模板
4. 初始化COLD层：空（等待后续归档）

### 流程2：角色记忆动态分层

**场景**: 根据角色权重，决定记忆加载策略

```javascript
// 高权重角色 - 加载HOT+WARM+COLD
function loadHighWeightCharacterMemory(characterId) {
  // 读取所有三层记忆
  const hotMemories = readHotMemory(characterId);
  const warmMemories = readWarmMemory(characterId);
  const coldMemories = readColdMemory(characterId);
  
  return {
    tier: 'FULL',
    memories: [...hotMemories, ...warmMemories, ...coldMemories]
  };
}

// 中权重角色 - 加载HOT+WARM
function loadMediumWeightCharacterMemory(characterId) {
  const hotMemories = readHotMemory(characterId);
  const warmMemories = readWarmMemory(characterId);
  
  return {
    tier: 'PARTIAL',
    memories: [...hotMemories, ...warmMemories]
  };
}

// 低权重角色 - 仅加载HOT（最新几条记忆）
function loadLowWeightCharacterMemory(characterId) {
  const hotMemories = readHotMemory(characterId, limit=3);
  
  return {
    tier: 'MINIMAL',
    memories: hotMemories
  };
}
```

### 流程3：回合结算后的记忆归档

**场景**: 每回合结束后，整理和归档记忆

```bash
# 触发自动归档
Run memory tiering
```

**执行步骤**:
1. **审计**: 读取所有三层和最近的每日日志
2. **识别**: 找出"死亡上下文"（已完成的任务、已解决的事件）
3. **重新分配**:
   - 当前活跃事件 → HOT
   - 新形成的角色偏好/关系 → WARM
   - 已完成的重要事件摘要 → COLD
4. **清理**: 从COLD中移除细节，保留摘要
5. **验证**: 确保关键信息未丢失，HOT层足够精简

### 流程4：紧急记忆加载（突发事件）

**场景**: 低权重角色突然触发重要事件，需要快速加载更多记忆

```javascript
// 角色权重临时提升，需要加载更多记忆
function emergencyMemoryLoad(characterId) {
  // 从WARM层加载相关记忆到HOT
  const relevantWarmMemories = searchWarmMemory(characterId, query="创伤 关键事件");
  
  // 提升到HOT层
  for (const memory of relevantWarmMemories) {
    moveToHot(memory);
  }
  
  // 触发分层整理
  triggerMemoryTiering();
}
```

---

## 四、天道系统集成方案

### 与权重系统的联动

| 角色权重 | 加载层级 | 记忆范围 | Token消耗 |
|---------|---------|---------|----------|
| 高权重 (>80) | FULL | HOT+WARM+COLD | 高 |
| 中权重 (40-80) | PARTIAL | HOT+WARM | 中 |
| 低权重 (<40) | MINIMAL | HOT only | 低 |
| 龙套 (<20) | SNAPSHOT | HOT latest 3 | 极低 |

### 与Y值系统的联动

```javascript
// 当角色Y值发生重大变化时，调整记忆层级
function onYValueChange(characterId, oldY, newY) {
  const delta = newY - oldY;
  
  if (Math.abs(delta) > 10) {
    // Y值大幅变化，将相关记忆提升到HOT
    const relevantMemories = searchAllTiers(characterId, query="情绪变化 触发事件");
    for (const memory of relevantMemories) {
      moveToHot(memory);
    }
  }
  
  // 触发分层整理
  triggerMemoryTiering();
}
```

### 记忆五类与三层的映射

| 天道记忆类型 | 默认层级 | 升级条件 |
|-------------|---------|---------|
| 总记忆 | COLD | 永不升级 |
| 常态记忆 | WARM | 当前活跃时→HOT |
| 异常记忆 | WARM | 触发补偿时→HOT |
| 长记忆 | COLD | 当前相关时→WARM |
| 短记忆 | HOT | 定期清理或归档到WARM |

---

## 五、触发条件

### 手动触发
```bash
Run memory tiering
整理记忆层级
```

### 自动触发
- 每次 `/compact` 命令后
- 每回合结算后
- 角色权重发生重大变化时
- Token消耗接近上限时

---

## 六、注意事项

1. **HOT层大小**: 保持HOT层精简，建议不超过5000 tokens
2. **WARM层审查**: 每周审查一次，移除不再相关的偏好
3. **COLD层摘要**: 定期将详细记录摘要化，保留核心信息
4. **敏感信息**: HOT层的凭证应指向根文件，不存储原始密钥

---

## 七、故障排查

| 问题 | 解决方案 |
|------|----------|
| HOT层过大 | 执行分层整理，将旧任务移到WARM |
| 记忆丢失 | 检查COLD层，确认是否正确归档 |
| 加载缓慢 | 减少高权重角色数量，或降低其记忆加载范围 |

---

*文档生成时间: 2026-04-17*  
*对应Skill: memory-tiering v1.0.0*
