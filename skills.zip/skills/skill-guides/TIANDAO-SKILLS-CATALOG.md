# 天道系统 Skill 完整清单

**生成时间**: 2026-04-17  
**总计安装**: 15个核心Skill  

---

## 📊 安装状态总览

| 优先级 | Skill名称 | 状态 | 用途 |
|--------|-----------|------|------|
| ⭐⭐⭐⭐⭐ | memory-qdrant | ✅ 已安装 | 向量数据库记忆管理 |
| ⭐⭐⭐⭐⭐ | memory-tiering | ✅ 已安装 | 记忆分层管理 |
| ⭐⭐⭐⭐⭐ | deep-reading | ✅ 已安装 | 深度精读学习 |
| ⭐⭐⭐⭐⭐ | self-evolving-skill | ✅ 已安装 | 自我进化 |
| ⭐⭐⭐⭐⭐ | auto-workflow-builder | ✅ 已安装 | 自动工作流 |
| ⭐⭐⭐⭐ | summarize-pro | ✅ 已安装 | 内容总结 |
| ⭐⭐⭐⭐ | n8n-workflow-automation | ✅ 已安装 | 工作流自动化 |
| ⭐⭐⭐⭐ | xiucheng-self-improving-agent | ✅ 已安装 | 自我改进Agent |
| ⭐⭐⭐⭐ | project-deep-analyzer | ✅ 已安装 | 项目深度分析 |
| ⭐⭐⭐⭐ | context-optimizer | ✅ 已安装 | 上下文优化 |
| ⭐⭐⭐⭐ | article-style-analyzer | ✅ 已安装 | 风格分析 |
| ⭐⭐⭐⭐ | viral-article-deconstructor | ✅ 已安装 | 爆款拆解 |
| ⭐⭐⭐ | insight-writer | ✅ 已安装 | 洞察写作 |
| ⭐⭐⭐ | ai-humanizer | ✅ 已安装 | 文本人性化 |
| ⭐⭐⭐ | workspace-maintenance | ✅ 已安装 | 工作空间维护 |
| ⭐⭐⭐ | file-auto-organizer | ✅ 已安装 | 文件自动整理 |
| ⭐⭐⭐ | memory-setup-openclaw | ✅ 已安装 | 记忆设置 |

---

## 🧠 核心记忆管理（第一优先级）

### 1. memory-qdrant
**功能**: 向量数据库语义记忆管理  
**天道应用**: 五类记忆存储与检索（总/常态/异常/长/短）  
**调用方式**:
```javascript
memory_store({text: "记忆内容", category: "memory_type"})
memory_search({query: "搜索关键词", limit: 5})
memory_forget({memoryId: "uuid"})
```

### 2. memory-tiering
**功能**: 三层记忆架构（HOT/WARM/COLD）  
**天道应用**: 基于权重的动态记忆加载  
**调用方式**:
```bash
Run memory tiering
整理记忆层级
```

### 3. memory-setup-openclaw
**功能**: OpenClaw记忆初始化设置  
**天道应用**: 系统启动时的记忆架构配置  
**调用方式**: 自动配置或手动初始化

---

## 📚 学习与经验积累（第二优先级）

### 4. deep-reading
**功能**: 深度精读小说，提取行为模式  
**天道应用**: 训练天道参数，学习人物心理特征  
**调用方式**:
```bash
精读 [书籍路径]
深度阅读 [文本内容]
```

### 5. summarize-pro
**功能**: 多格式内容总结  
**天道应用**: 提炼小说核心情节和人物关系  
**调用方式**:
```bash
summarize [文本]
tldr [文本]
key takeaways [文本]
```

### 6. article-style-analyzer
**功能**: 分析文章写作风格  
**天道应用**: 提取不同作者的叙事模式  
**调用方式**: 分析样本文章，输出风格报告

### 7. viral-article-deconstructor
**功能**: 拆解爆款文章  
**天道应用**: 分析意外性生成机制  
**调用方式**: 拆解文章，分析核心观点和说服策略

---

## 🔄 自我迭代与优化（第三优先级）

### 8. self-evolving-skill
**功能**: 自我进化能力  
**天道应用**: 系统自我迭代优化  
**调用方式**: 自动运行或手动触发进化

### 9. xiucheng-self-improving-agent
**功能**: 自我改进Agent  
**天道应用**: 持续学习和参数调优  
**调用方式**: 持续运行，自动优化

### 10. context-optimizer
**功能**: 上下文优化  
**天道应用**: 减少Token消耗，优化记忆加载  
**调用方式**: 自动优化或手动触发

---

## 🤖 自动化与执行（第四优先级）

### 11. auto-workflow-builder
**功能**: 自动工作流构建  
**天道应用**: 搭建天道-人道运行流程  
**调用方式**: 自动构建工作流

### 12. n8n-workflow-automation
**功能**: n8n工作流自动化  
**天道应用**: 系统自动化运行  
**调用方式**: 配置n8n工作流

---

## 🔍 分析与监控（第五优先级）

### 13. project-deep-analyzer
**功能**: 深度项目分析  
**天道应用**: 分析系统运行状态和性能  
**调用方式**: 分析项目结构和运行数据

---

## 📝 内容生成与处理（第六优先级）

### 14. insight-writer
**功能**: 深度洞察撰稿  
**天道应用**: 生成符合天道规则的叙事文本  
**调用方式**: 生成高质量文案

### 15. ai-humanizer
**功能**: AI文本人性化  
**天道应用**: 去除AI痕迹，让生成文本更自然  
**调用方式**: 处理AI生成文本

---

## 🔧 系统维护（第七优先级）

### 16. workspace-maintenance
**功能**: 工作空间维护  
**天道应用**: 管理系统数据和配置  
**调用方式**: 定期维护工作空间

### 17. file-auto-organizer
**功能**: 文件自动整理  
**天道应用**: 整理系统生成的海量数据  
**调用方式**: 自动整理文件

---

## 🚀 快速启动流程

### 步骤1: 初始化记忆系统
```bash
# 1. 配置memory-qdrant
# 2. 运行memory-setup-openclaw
# 3. 执行memory-tiering整理层级
```

### 步骤2: 加载学习数据
```bash
# 1. 使用deep-reading精读训练小说
# 2. 使用summarize-pro提炼核心内容
# 3. 使用article-style-analyzer分析风格
```

### 步骤3: 启动自动化工作流
```bash
# 1. 使用auto-workflow-builder构建流程
# 2. 使用n8n-workflow-automation自动化运行
# 3. 启用self-evolving-skill和自我改进
```

### 步骤4: 监控与优化
```bash
# 1. 使用project-deep-analyzer分析运行状态
# 2. 使用context-optimizer优化Token消耗
# 3. 定期执行workspace-maintenance维护系统
```

---

## 📁 文档位置

所有详细调用文档位于:
```
C:\Users\shaoy\.stepclaw\workspace\skill-guides\
├── 01-memory-qdrant-guide.md
├── 02-memory-tiering-guide.md
├── 03-deep-reading-guide.md (待生成)
├── 04-self-evolving-guide.md (待生成)
├── ...
└── TIANDAO-SKILLS-CATALOG.md (本文件)
```

---

## ⚠️ 注意事项

1. **首次运行**: memory-qdrant会下载25MB嵌入模型
2. **依赖关系**: 部分skill需要Node.js和npm
3. **配置顺序**: 建议按优先级顺序配置
4. **Token优化**: 务必启用context-optimizer

---

*最后更新: 2026-04-17*
