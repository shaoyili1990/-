# 天道系统 Skill 统一调度操作手册

**文档版本**: 1.0  
**创建时间**: 2026-04-17  
**适用范围**: 天道系统 + 人道系统 完整运行流程  

---

## 📋 目录

1. [系统架构概览](#一系统架构概览)
2. [启动流程](#二启动流程)
3. [回合运行流程](#三回合运行流程)
4. [Skill调用矩阵](#四skill调用矩阵)
5. [异常处理](#五异常处理)
6. [监控与维护](#六监控与维护)

---

## 一、系统架构概览

### 1.1 核心组件关系图

```
┌─────────────────────────────────────────────────────────────┐
│                      天道系统 (TianDao)                      │
│                  个体心理动力学模拟层                         │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  Y值计算引擎  │  │ 触发补偿机制  │  │ 记忆管理系统  │      │
│  │ (context-    │  │ (self-       │  │ (memory-     │      │
│  │  optimizer)  │  │  evolving)   │  │  qdrant)     │      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │
│         │                 │                 │              │
│         └─────────────────┼─────────────────┘              │
│                           ▼                                │
│              ┌────────────────────────┐                    │
│              │   角色状态渲染引擎      │                    │
│              │  (insight-writer +     │                    │
│              │   ai-humanizer)        │                    │
│              └───────────┬────────────┘                    │
└──────────────────────────┼─────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                      人道系统 (RenDao)                       │
│                   社会群体动力学模拟层                        │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ 权重计算中心  │  │ 记忆传播网络  │  │ 老天爷评判   │      │
│  │ (memory-     │  │ (memory-     │  │ (project-    │      │
│  │  tiering)    │  │  qdrant)     │  │  deep-       │      │
│  │              │  │              │  │  analyzer)   │      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │
│         │                 │                 │              │
│         └─────────────────┼─────────────────┘              │
│                           ▼                                │
│              ┌────────────────────────┐                    │
│              │   世界状态渲染引擎      │                    │
│              │  (insight-writer +     │                    │
│              │   ai-humanizer)        │                    │
│              └───────────┬────────────┘                    │
└──────────────────────────┼─────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│                      学习与进化层                            │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │ 小说学习引擎  │  │ 经验提炼系统  │  │ 自我进化中心  │      │
│  │ (deep-       │  │ (summarize-   │  │ (xiucheng-   │      │
│  │  reading)    │  │  pro)        │  │  self-       │      │
│  │              │  │              │  │  improving)  │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└─────────────────────────────────────────────────────────────┘
```

### 1.2 数据流向图

```
输入层 (小说/设定/指令)
    │
    ▼
┌──────────────────────────────────────┐
│ 学习层 (deep-reading + summarize-pro) │
│ 提取行为模式、心理特征、叙事规律       │
└──────────────┬───────────────────────┘
               │ 训练数据
               ▼
┌──────────────────────────────────────┐
│ 天道层 (个体心理模拟)                  │
│ Y值变化 → 触发检测 → 补偿行为计算      │
└──────────────┬───────────────────────┘
               │ 角色行为输出
               ▼
┌──────────────────────────────────────┐
│ 人道层 (社会群体模拟)                  │
│ 权重计算 → 记忆传播 → 老天爷评判       │
└──────────────┬───────────────────────┘
               │ 世界状态输出
               ▼
┌──────────────────────────────────────┐
│ 渲染层 (insight-writer + ai-humanizer)│
│ 生成自然语言叙事文本                   │
└──────────────┬───────────────────────┘
               │ 最终输出
               ▼
           用户/读者
```

---

## 二、启动流程

### 2.1 系统初始化序列

```bash
# ============================================
# 阶段1: 基础设施初始化
# ============================================

# 1.1 初始化记忆存储 (memory-qdrant)
# 作用: 建立向量数据库，准备五类记忆存储
# 触发条件: 系统首次启动或重置
# 耗时: 约30秒（首次需下载25MB模型）

function initMemoryStorage() {
    # 检查Qdrant连接
    memory_qdrant_status()
    
    # 创建记忆集合
    memory_create_collection({
        name: "tiandao_memories",
        vector_size: 384,
        distance: "Cosine"
    })
    
    # 创建索引
    memory_create_index({
        collection: "tiandao_memories",
        field: "character_id"
    })
    memory_create_index({
        collection: "tiandao_memories",
        field: "memory_type"
    })
    
    log("记忆存储初始化完成")
}

# 1.2 配置记忆分层 (memory-tiering)
# 作用: 建立HOT/WARM/COLD三层架构
# 触发条件: 跟随记忆存储初始化

function initMemoryTiers() {
    # 创建目录结构
    create_directory("memory/hot/")
    create_directory("memory/warm/")
    
    # 初始化HOT层（空）
    write_file("memory/hot/HOT_MEMORY.md", "# HOT Memory\n\n## 当前活跃角色\n\n")
    
    # 初始化WARM层（基础设定）
    write_file("memory/warm/WARM_MEMORY.md", "# WARM Memory\n\n## 世界基础设定\n## 角色类型模板\n\n")
    
    # COLD层已存在（MEMORY.md）
    
    log("记忆分层初始化完成")
}

# 1.3 配置OpenClaw记忆 (memory-setup-openclaw)
# 作用: 配置OpenClaw的记忆插件

function initOpenClawMemory() {
    # 配置自动召回
    config_set({
        "plugins.memory-qdrant.enabled": true,
        "plugins.memory-qdrant.autoRecall": true,
        "plugins.memory-qdrant.autoCapture": false
    })
    
    log("OpenClaw记忆配置完成")
}

# ============================================
# 阶段2: 学习层初始化
# ============================================

# 2.1 加载训练数据 (deep-reading)
# 作用: 读取训练小说，提取心理模型参数
# 触发条件: 有新训练数据时

function loadTrainingData(novelPath) {
    # 深度阅读小说
    deep_read({
        path: novelPath,
        extract_patterns: [
            "人物心理变化",
            "行为触发因素",
            "补偿行为模式",
            "社会关系权重"
        ]
    })
    
    # 提取核心内容
    summary = summarize_pro({
        source: novelPath,
        focus: ["人物关系", "心理转折", "关键事件"]
    })
    
    # 存储到WARM层
    memory_store({
        text: summary,
        category: "training_data",
        tier: "WARM"
    })
    
    log("训练数据加载完成: " + novelPath)
}

# 2.2 分析叙事风格 (article-style-analyzer)
# 作用: 分析不同作者的叙事模式

function analyzeNarrativeStyles(sampleTexts) {
    for (text in sampleTexts) {
        style_report = analyze_style({
            text: text,
            aspects: ["叙事节奏", "对话风格", "心理描写", "意外性设计"]
        })
        
        memory_store({
            text: style_report,
            category: "narrative_style",
            tier: "WARM"
        })
    }
    
    log("叙事风格分析完成")
}

# ============================================
# 阶段3: 天道系统初始化
# ============================================

# 3.1 创建角色档案
# 作用: 为每个角色建立初始状态

function createCharacterProfile(characterId, initialParams) {
    # 存储角色基础信息到总记忆
    memory_store({
        text: JSON.stringify(initialParams),
        category: "total_memory",
        metadata: {
            character_id: characterId,
            memory_type: "total",
            y_value: initialParams.y_value || 50,
            weight: initialParams.weight || 50
        }
    })
    
    # 存储初始常态记忆
    for (memory in initialParams.normal_memories) {
        memory_store({
            text: memory,
            category: "normal_memory",
            metadata: {
                character_id: characterId,
                memory_type: "normal"
            }
        })
    }
    
    log("角色档案创建完成: " + characterId)
}

# 3.2 初始化上下文优化器 (context-optimizer)
# 作用: 配置Token消耗优化策略

function initContextOptimizer() {
    config_set({
        "context_optimizer.max_tokens": 8000,
        "context_optimizer.compression_threshold": 0.7,
        "context_optimizer.pruning_strategy": "weight_based"
    })
    
    log("上下文优化器初始化完成")
}

# ============================================
# 阶段4: 人道系统初始化
# ============================================

# 4.1 建立社会关系网络
# 作用: 初始化角色间的权重关系

function initSocialNetwork(characters) {
    for (i = 0; i < characters.length; i++) {
        for (j = i + 1; j < characters.length; j++) {
            charA = characters[i]
            charB = characters[j]
            
            # 计算初始权重
            initialWeight = calculateInitialWeight(charA, charB)
            
            # 存储关系
            memory_store({
                text: charA + " 与 " + charB + " 的初始权重: " + initialWeight,
                category: "social_relation",
                metadata: {
                    character_a: charA,
                    character_b: charB,
                    weight: initialWeight
                }
            })
        }
    }
    
    log("社会关系网络初始化完成")
}

# ============================================
# 阶段5: 自动化工作流配置
# ============================================

# 5.1 构建自动工作流 (auto-workflow-builder)
# 作用: 创建天道-人道运行流程

function buildAutoWorkflow() {
    workflow = auto_workflow_build({
        name: "tiandao_rendao_cycle",
        steps: [
            { name: "y_value_update", skill: "context-optimizer" },
            { name: "trigger_detection", skill: "memory-qdrant" },
            { name: "compensation_calc", skill: "self-evolving-skill" },
            { name: "weight_update", skill: "memory-tiering" },
            { name: "narrative_render", skill: "insight-writer" }
        ]
    })
    
    log("自动工作流构建完成")
}

# 5.2 配置n8n自动化 (n8n-workflow-automation)
# 作用: 设置定时任务和触发器

function configureN8nAutomation() {
    n8n_workflow_create({
        name: "tiandao_daily_cycle",
        trigger: "cron",
        schedule: "0 */6 * * *",  # 每6小时运行一次
        actions: [
            { type: "skill", name: "memory-tiering" },
            { type: "skill", name: "context-optimizer" },
            { type: "skill", name: "xiucheng-self-improving-agent" }
        ]
    })
    
    log("n8n自动化配置完成")
}

# ============================================
# 主启动函数
# ============================================

function startupTiandaoSystem(config) {
    log("===== 天道系统启动 =====")
    
    # 阶段1: 基础设施
    initMemoryStorage()
    initMemoryTiers()
    initOpenClawMemory()
    
    # 阶段2: 学习层
    if (config.training_novels) {
        for (novel in config.training_novels) {
            loadTrainingData(novel)
        }
    }
    if (config.style_samples) {
        analyzeNarrativeStyles(config.style_samples)
    }
    
    # 阶段3: 天道系统
    for (char in config.characters) {
        createCharacterProfile(char.id, char.params)
    }
    initContextOptimizer()
    
    # 阶段4: 人道系统
    initSocialNetwork(config.characters.map(c => c.id))
    
    # 阶段5: 自动化
    buildAutoWorkflow()
    configureN8nAutomation()
    
    # 启动自我进化
    self_evolving_start()
    xiucheng_self_improving_start()
    
    log("===== 天道系统启动完成 =====")
}
```

---

## 三、回合运行流程

### 3.1 标准回合处理流程

```
┌─────────────────────────────────────────────────────────────┐
│                     回合开始 (Turn Start)                    │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ 步骤1: 加载角色记忆 (memory-tiering + memory-qdrant)         │
│ - 根据权重决定加载层级 (HOT/WARM/COLD)                        │
│ - 检索相关记忆 (触发条件、历史互动)                            │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ 步骤2: 更新Y值 (context-optimizer)                           │
│ - 应用自然波动 (±1)                                          │
│ - 应用事件影响                                               │
│ - 检查触发阈值                                               │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ 步骤3: 触发检测 (memory-qdrant)                              │
│ - 搜索相关创伤/异常记忆                                        │
│ - 计算触发概率                                                │
│ - 确定触发强度                                                │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ 步骤4: 补偿行为计算 (self-evolving-skill)                    │
│ - 确定补偿方向 (攻击/逃避/讨好/僵住)                          │
│ - 计算补偿强度                                                │
│ - 生成具体行为                                                │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ 步骤5: 权重更新 (memory-tiering)                             │
│ - 计算权重变化 (ΔW = 事件影响 × 关系系数)                      │
│ - 更新社会关系网络                                            │
│ - 触发老天爷评判 (如需要)                                      │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ 步骤6: 记忆存储 (memory-qdrant)                              │
│ - 存储新事件到短记忆                                          │
│ - 重要事件升级到中/长记忆                                      │
│ - 异常事件标记                                                │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ 步骤7: 叙事渲染 (insight-writer + ai-humanizer)              │
│ - 生成自然语言描述                                            │
│ - 人性化处理 (去除AI痕迹)                                     │
│ - 输出最终文本                                                │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ 步骤8: 自我进化 (xiucheng-self-improving-agent)              │
│ - 分析本轮运行效果                                            │
│ - 调整参数 (如需要)                                           │
│ - 记录改进点                                                  │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                      回合结束 (Turn End)                     │
└─────────────────────────────────────────────────────────────┘
```

### 3.2 回合处理代码实现

```javascript
// ============================================
// 回合主函数
// ============================================

function processTurn(turnData) {
    log("===== 回合 " + turnData.turn_id + " 开始 =====")
    
    // 步骤1: 加载角色记忆
    characterMemories = loadCharacterMemories(turnData.active_characters)
    
    // 步骤2-4: 天道系统处理 (个体心理)
    tiandaoResults = processTiandaoLayer({
        characters: turnData.active_characters,
        events: turnData.events,
        memories: characterMemories
    })
    
    // 步骤5-6: 人道系统处理 (社会群体)
    rendaoResults = processRendaoLayer({
        characters: turnData.active_characters,
        tiandao_outputs: tiandaoResults,
        social_network: turnData.social_network
    })
    
    // 步骤7: 叙事渲染
    narrative = renderNarrative({
        tiandao: tiandaoResults,
        rendao: rendaoResults
    })
    
    // 步骤8: 自我进化
    selfImprovement = processSelfImprovement({
        turn_data: turnData,
        results: {
            tiandao: tiandaoResults,
            rendao: rendaoResults,
            narrative: narrative
        }
    })
    
    log("===== 回合 " + turnData.turn_id + " 结束 =====")
    
    return {
        narrative: narrative,
        character_states: tiandaoResults.final_states,
        social_network: rendaoResults.updated_network,
        improvements: selfImprovement
    }
}

// ============================================
// 天道层处理 (个体心理)
// ============================================

function processTiandaoLayer(input) {
    results = []
    
    for (character of input.characters) {
        // 2. 更新Y值
        newY = updateYValue({
            character_id: character.id,
            current_y: character.y_value,
            events: input.events
        })
        
        // 3. 触发检测
        trigger = detectTrigger({
            character_id: character.id,
            y_value: newY,
            memories: input.memories[character.id]
        })
        
        // 4. 补偿行为计算
        if (trigger.triggered) {
            compensation = calculateCompensation({
                character_id: character.id,
                trigger: trigger,
                memories: input.memories[character.id]
            })
        } else {
            compensation = null
        }
        
        results.push({
            character_id: character.id,
            y_value: newY,
            trigger: trigger,
            compensation: compensation
        })
    }
    
    return { character_outputs: results }
}

// Y值更新
function updateYValue(params) {
    // 自然波动
    naturalFluctuation = random_range(-1, 1)
    
    // 事件影响
    eventImpact = 0
    for (event of params.events) {
        if (event.target_character == params.character_id) {
            eventImpact += event.y_impact
        }
    }
    
    // 计算新Y值
    newY = params.current_y + naturalFluctuation + eventImpact
    newY = clamp(newY, 0, 100)  // 限制在0-100范围
    
    // 使用context-optimizer优化存储
    context_optimizer_store({
        key: "y_value_" + params.character_id,
        value: newY,
        priority: "high"
    })
    
    return newY
}

// 触发检测
function detectTrigger(params) {
    // 使用memory-qdrant搜索相关异常记忆
    abnormalMemories = memory_search({
        query: "创伤 痛苦 " + params.y_value,
        filter: {
            character_id: params.character_id,
            memory_type: "abnormal"
        },
        limit: 5
    })
    
    // 计算触发概率
    triggerProbability = 0
    for (memory of abnormalMemories) {
        // 基于Y值和记忆强度计算
        relevance = calculateRelevance(memory, params.y_value)
        triggerProbability += relevance * 0.2
    }
    
    triggered = random() < triggerProbability
    
    return {
        triggered: triggered,
        probability: triggerProbability,
        relevant_memories: abnormalMemories
    }
}

// 补偿行为计算
function calculateCompensation(params) {
    // 使用self-evolving-skill计算最优补偿策略
    compensation = self_evolving_compute({
        character_id: params.character_id,
        trigger: params.trigger,
        available_actions: ["attack", "avoid", "please", "freeze"],
        constraints: {
            max_intensity: params.trigger.probability * 10,
            character_traits: getCharacterTraits(params.character_id)
        }
    })
    
    return compensation
}

// ============================================
// 人道层处理 (社会群体)
// ============================================

function processRendaoLayer(input) {
    // 5. 权重更新
    updatedNetwork = updateSocialWeights({
        characters: input.characters,
        tiandao_outputs: input.tiandao_outputs,
        current_network: input.social_network
    })
    
    // 6. 记忆传播
    propagateMemories({
        characters: input.characters,
        events: extractEvents(input.tiandao_outputs),
        network: updatedNetwork
    })
    
    // 老天爷评判 (如需要)
    laotianyeJudgement = null
    if (shouldTriggerJudgement(updatedNetwork)) {
        laotianyeJudgement = performLaotianyeJudgement({
            network: updatedNetwork,
            recent_events: extractEvents(input.tiandao_outputs)
        })
    }
    
    return {
        updated_network: updatedNetwork,
        judgement: laotianyeJudgement
    }
}

// 权重更新
function updateSocialWeights(params) {
    network = params.current_network
    
    for (output of params.tiandao_outputs) {
        if (output.compensation) {
            // 补偿行为影响相关角色权重
            affectedCharacters = getRelatedCharacters(output.character_id)
            
            for (affected of affectedCharacters) {
                // 计算权重变化
                deltaW = calculateWeightDelta({
                    action: output.compensation,
                    relationship: network[output.character_id][affected]
                })
                
                // 更新权重
                network[output.character_id][affected] += deltaW
                
                // 使用memory-tiering管理权重记忆
                memory_tiering_store({
                    character_a: output.character_id,
                    character_b: affected,
                    weight: network[output.character_id][affected],
                    delta: deltaW,
                    reason: output.compensation.type
                })
            }
        }
    }
    
    return network
}

// ============================================
// 叙事渲染
// ============================================

function renderNarrative(params) {
    // 使用insight-writer生成叙事
    rawNarrative = insight_writer_generate({
        tiandao_events: params.tiandao.character_outputs,
        rendao_changes: params.rendao.updated_network,
        style: getNarrativeStyle(),
        length: "medium"
    })
    
    // 使用ai-humanizer人性化处理
    finalNarrative = ai_humanizer_process({
        text: rawNarrative,
        tone: "natural",
        remove_ai_markers: true
    })
    
    return finalNarrative
}

// ============================================
// 自我进化
// ============================================

function processSelfImprovement(params) {
    // 使用xiucheng-self-improving-agent分析
    analysis = xiucheng_self_improving_analyze({
        turn_data: params.turn_data,
        results: params.results,
        metrics: ["narrative_quality", "character_consistency", "plot_coherence"]
    })
    
    // 如果有改进空间，调整参数
    if (analysis.improvement_needed) {
        self_evolving_adjust({
            parameters: analysis.suggested_parameters,
            confidence: analysis.confidence
        })
    }
    
    return analysis
}
```

---

## 四、Skill调用矩阵

### 4.1 按功能分类的Skill调用表

| 功能模块 | 核心Skill | 调用时机 | 输入参数 | 输出结果 |
|---------|----------|---------|---------|---------|
| **记忆存储** | memory-qdrant | 事件发生后 | text, category, metadata | memory_id |
| **记忆检索** | memory-qdrant | 回合开始时 | query, filter, limit | memories[] |
| **记忆分层** | memory-tiering | 回合结束时 | - | - |
| **Y值优化** | context-optimizer | Y值变化时 | key, value, priority | optimized_value |
| **触发检测** | self-evolving-skill | Y值更新后 | character_state, memories | trigger_result |
| **补偿计算** | self-evolving-skill | 触发检测后 | trigger, constraints | compensation_action |
| **权重更新** | memory-tiering | 行为发生后 | relation_data | updated_weights |
| **叙事生成** | insight-writer | 回合结束前 | events, style | narrative_text |
| **文本优化** | ai-humanizer | 叙事生成后 | text, tone | humanized_text |
| **自我改进** | xiucheng-self-improving-agent | 回合结束后 | turn_data, results | improvement_plan |
| **深度分析** | project-deep-analyzer | 定期/按需 | project_data | analysis_report |
| **工作流构建** | auto-workflow-builder | 初始化时 | workflow_config | workflow_definition |
| **自动化执行** | n8n-workflow-automation | 定时触发 | workflow_name | execution_result |

### 4.2 调用频率与性能考量

| Skill | 调用频率 | 平均耗时 | Token消耗 | 优化策略 |
|-------|---------|---------|----------|---------|
| memory-qdrant | 每回合多次 | 50-200ms | 低 | 批量查询，缓存热点 |
| memory-tiering | 每回合1次 | 100-500ms | 中 | 异步执行，延迟归档 |
| context-optimizer | 每角色1次 | 10-50ms | 低 | 增量更新，局部优化 |
| self-evolving-skill | 触发时 | 200-1000ms | 高 | 缓存模型，批处理 |
| insight-writer | 每回合1次 | 500-2000ms | 高 | 模板化，分段生成 |
| ai-humanizer | 每回合1次 | 300-800ms | 中 | 规则优先，AI辅助 |
| xiucheng-self-improving-agent | 每N回合1次 | 1000-5000ms | 高 | 后台执行，非阻塞 |

---

## 五、异常处理

### 5.1 常见异常及处理方案

```javascript
// ============================================
// 异常处理中心
// ============================================

function handleException(error, context) {
    log("异常捕获: " + error.type + " - " + error.message)
    
    switch (error.type) {
        case "MEMORY_QDRANT_CONNECTION_LOST":
            // 记忆数据库连接丢失
            handleMemoryConnectionLost(context)
            break
            
        case "MEMORY_TIERING_OVERFLOW":
            // 记忆分层溢出
            handleMemoryTieringOverflow(context)
            break
            
        case "CONTEXT_OPTIMIZER_LIMIT_EXCEEDED":
            // Token限制超出
            handleContextLimitExceeded(context)
            break
            
        case "SELF_EVOLVING_CONVERGENCE_FAILED":
            // 自我进化收敛失败
            handleEvolutionConvergenceFailed(context)
            break
            
        case "INSIGHT_WRITER_GENERATION_FAILED":
            // 叙事生成失败
            handleNarrativeGenerationFailed(context)
            break
            
        default:
            handleUnknownError(error, context)
    }
}

// 记忆数据库连接丢失
function handleMemoryConnectionLost(context) {
    // 1. 切换到内存模式
    memory_qdrant_switch_mode("in_memory")
    
    // 2. 记录待同步数据
    queueForSync(context.pending_memories)
    
    // 3. 尝试重连
    scheduleRetry(() => {
        memory_qdrant_reconnect()
    }, delay=5000)
    
    // 4. 继续运行（降级模式）
    return { degraded: true, mode: "in_memory" }
}

// Token限制超出
function handleContextLimitExceeded(context) {
    // 1. 紧急清理HOT层
    memory_tiering_emergency_prune({
        target_tier: "HOT",
        keep_count: 3  // 只保留最近3条
    })
    
    // 2. 压缩长记忆
    context_optimizer_compress({
        compression_ratio: 0.5,
        priority: "high"
    })
    
    // 3. 如果仍超出，跳过非关键角色
    if (context_optimizer_check_limit() > 0.9) {
        context.skip_characters = selectLowWeightCharacters(context.characters, keep=5)
    }
    
    return { recovered: true, skipped: context.skip_characters }
}

// 叙事生成失败
function handleNarrativeGenerationFailed(context) {
    // 1. 使用简化模板
    fallbackNarrative = generateFallbackNarrative({
        events: context.events,
        template: "simple"
    })
    
    // 2. 记录失败原因
    project_deep_analyzer_log({
        type: "narrative_generation_failure",
        context: context,
        fallback_used: true
    })
    
    // 3. 尝试修复并继续
    return { narrative: fallbackNarrative, fallback: true }
}
```

---

## 六、监控与维护

### 6.1 日常监控指标

```javascript
// ============================================
// 系统监控
// ============================================

function systemHealthCheck() {
    metrics = {
        // 记忆系统健康度
        memory: {
            qdrant_status: memory_qdrant_health(),
            tier_distribution: memory_tiering_stats(),
            total_memories: memory_qdrant_count(),
            query_latency: memory_qdrant_avg_latency()
        },
        
        // 性能指标
        performance: {
            avg_turn_time: calculateAvgTurnTime(last=100),
            token_usage: context_optimizer_get_stats(),
            cache_hit_rate: getCacheHitRate()
        },
        
        // 进化状态
        evolution: {
            last_improvement: xiucheng_self_improving_last_update(),
            parameter_changes: self_evolving_get_changes(),
            convergence_score: self_evolving_convergence_score()
        },
        
        // 叙事质量
        narrative: {
            avg_generation_time: insight_writer_avg_time(),
            humanizer_effectiveness: ai_humanizer_effectiveness(),
            fallback_rate: calculateFallbackRate()
        }
    }
    
    // 使用project-deep-analyzer生成报告
    report = project_deep_analyzer_generate({
        metrics: metrics,
        format: "dashboard"
    })
    
    return report
}
```

### 6.2 定期维护任务

```bash
# ============================================
# 每日维护 (由n8n-workflow-automation触发)
# ============================================

# 1. 记忆归档
Run memory tiering
# - 将HOT层过期内容移到WARM
# - 将WARM层稳定内容移到COLD

# 2. 上下文优化
context-optimizer --defragment
# - 整理内存碎片
# - 压缩冗余数据

# 3. 系统健康检查
project-deep-analyzer --health-check
# - 生成健康报告
# - 检测异常指标

# ============================================
# 每周维护
# ============================================

# 1. 深度分析
project-deep-analyzer --deep-analysis
# - 分析长期趋势
# - 识别改进机会

# 2. 自我进化评估
xiucheng-self-improving-agent --evaluate
# - 评估进化效果
# - 调整进化策略

# 3. 工作空间维护
workspace-maintenance --cleanup
# - 清理临时文件
# - 归档旧数据

# ============================================
# 每月维护
# ============================================

# 1. 全面系统审查
project-deep-analyzer --full-audit

# 2. 参数调优
self-evolving-skill --tune-parameters

# 3. 备份
file-auto-organizer --backup-all
```

---

## 附录A: 快速参考卡片

### A1. 常用命令速查

```bash
# 系统启动
startup-tiandao --config config.json

# 单回合处理
process-turn --input turn_data.json

# 紧急优化
context-optimizer --emergency --target HOT

# 记忆查询
memory-search --query "关键词" --character 角色ID

# 生成叙事
insight-writer --events events.json --style default

# 系统状态
system-status --verbose
```

### A2. 配置参数参考

```json
{
  "tiandao": {
    "y_value": {
      "natural_fluctuation_range": [-1, 1],
      "trigger_threshold": 0.7,
      "compensation_decay": 0.9
    },
    "memory": {
      "hot_max_size": 5000,
      "warm_max_size": 20000,
      "short_term_ttl": 86400
    }
  },
  "rendao": {
    "weight": {
      "initial_range": [30, 70],
      "max_change_per_turn": 10,
      "judgement_threshold": 0.8
    }
  },
  "performance": {
    "max_tokens_per_turn": 8000,
    "target_turn_time_ms": 5000,
    "cache_ttl_seconds": 3600
  }
}
```

---

*文档结束*  
*最后更新: 2026-04-17*
