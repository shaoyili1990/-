"""
处理《次元笔记本》第一卷 少年歌行 第3-64章
调用MiniMax API进行天道系统分析
"""

import os
import sys
import json
import re
import httpx
import base64
from pathlib import Path
from datetime import datetime

# 添加src目录到路径
sys.path.insert(0, str(Path(__file__).parent / "src"))

# 导入项目的MiniMax API类
from api.minimax_api import MiniMaxAPI

def call_minimax_api(content: str, chapter_num: int, chapter_title: str) -> dict:
    """调用MiniMax API分析章节"""
    system_prompt = """你是一位天道系统分析师。根据小说章节内容，提取：

1. 人物快照（数组）- name, mbti, base_y, current_y, baseline_y, weight, role, current_state, current_desire, emotions
2. 事件卡（数组）- id, title, cause, process, result, characters_involved, type, y_value_changes, butterfly_effect, tiandao_judgment
3. 时空切片（对象）- chapter_title, volume, chapter_number, world_state, characters_present, tiandao_state, rendao_state, causal_state

返回完整JSON格式。"""

    # 限制内容长度
    text = content[:25000] if len(content) > 25000 else content

    user_prompt = f"""分析以下章节内容：

章节标题：{chapter_title}
章节内容：
{text}

请以JSON格式返回完整的分析结果，包含characters（人物快照数组）、events（事件卡数组）、spacetime_slice（时空切片对象）。"""

    # 使用项目的MiniMaxAPI类
    api = MiniMaxAPI()

    if not api.is_configured():
        return {"error": "API not configured. Please check your API key."}

    result = api._call([
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ], temperature=0.7, max_tokens=3000)

    # 尝试解析JSON
    if result.startswith("【错误】"):
        return {"error": result}

    try:
        if "```json" in result:
            result = result.split("```json")[1].split("```")[0]
        elif "```" in result:
            result = result.split("```")[1].split("```")[0]
        return json.loads(result.strip())
    except Exception as e:
        return {"error": f"JSON解析失败: {str(e)}, 原始结果: {result[:500]}"}

def split_by_chapters(text: str) -> list:
    """按章节分割小说文本 - 处理重复章节号"""
    chapters = []
    lines = text.split('\n')
    current_chapter = None
    current_content = []
    seen_chapters = {}  # 跟踪已处理的章节号

    # 更严格的模式：第X章：标题（标题在同行）
    chapter_pattern = re.compile(r'^第([一二三四五六七八九十百千\d]+)章[：:][^\n]*$')

    for line in lines:
        match = chapter_pattern.match(line.strip())
        if match:
            # 保存上一章
            if current_chapter is not None:
                content = '\n'.join(current_content)
                if content.strip():
                    chapters.append((current_chapter[0], current_chapter[1], content))

            title = line.strip()
            num_str = match.group(1)
            chapter_num = chinese_to_number(num_str)

            # 处理重复章节号：如果是重复的，在标题后加序号
            if chapter_num in seen_chapters:
                seen_chapters[chapter_num] += 1
                suffix = f"_part{seen_chapters[chapter_num]}"
                title = title + suffix
            else:
                seen_chapters[chapter_num] = 1

            current_chapter = (chapter_num, title)
            current_content = []
        elif current_chapter is not None:
            current_content.append(line)

    # 保存最后一章
    if current_chapter is not None:
        content = '\n'.join(current_content)
        if content.strip():
            chapters.append((current_chapter[0], current_chapter[1], content))

    return chapters

def chinese_to_number(chinese: str) -> int:
    """将中文数字转换为整数"""
    chinese_map = {
        '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
        '六': 6, '七': 7, '八': 8, '九': 9, '十': 10,
        '百': 100, '千': 1000, '万': 10000
    }

    if chinese.isdigit():
        return int(chinese)

    result = 0
    temp = 0

    for char in chinese:
        if char in chinese_map:
            value = chinese_map[char]
            if value >= 1000:
                result += temp * value
                temp = 0
            elif value >= 100:
                temp = value
            else:
                temp += value

    return result + temp

def save_chapter_analysis(chapter_num: int, chapter_title: str, content: str, analysis: dict, output_dir: Path):
    """保存章节分析结果"""
    # 创建目录
    chapter_dir = output_dir / f"ch{chapter_num:02d}_{chapter_title[:30]}"
    chapter_dir.mkdir(parents=True, exist_ok=True)

    # 1. 保存原始章节内容
    (chapter_dir / "chapter_content.txt").write_text(content, encoding='utf-8')

    # 2. 保存时空切片
    spacetime = analysis.get("spacetime_slice", {})
    if not spacetime:
        spacetime = {
            "chapter_title": chapter_title,
            "volume": "第一卷",
            "chapter_number": f"第{chapter_num}章",
            "world_state": "天道异动后的世界状态",
            "characters_present": [],
            "tiandao_state": "待观察",
            "rendao_state": "待观察",
            "causal_state": "因果待定"
        }
    spacetime_path = chapter_dir / "spacetime_slice.json"
    spacetime_path.write_text(json.dumps(spacetime, ensure_ascii=False, indent=2), encoding='utf-8')

    # 3. 保存人物快照
    characters_dir = chapter_dir / "characters"
    characters_dir.mkdir(exist_ok=True)

    characters = analysis.get("characters", [])
    if not characters:
        characters = []

    for i, char in enumerate(characters):
        char_name = char.get("name", f"角色{i+1}")
        char_path = characters_dir / f"{char_name}.json"
        char_path.write_text(json.dumps(char, ensure_ascii=False, indent=2), encoding='utf-8')

    # 4. 保存事件卡
    events_dir = chapter_dir / "events"
    events_dir.mkdir(exist_ok=True)

    events = analysis.get("events", [])
    if not events:
        events = []

    for i, event in enumerate(events):
        event_id = event.get("id", f"E{chapter_num:03d}_{i+1:02d}")
        event_path = events_dir / f"{event_id}.json"
        event_path.write_text(json.dumps(event, ensure_ascii=False, indent=2), encoding='utf-8')

    print(f"  - 已保存: {chapter_title[:20]}... ({len(characters)}个角色, {len(events)}个事件)")

def main():
    # 路径配置
    source_file = Path(r"C:\Users\shaoy\Desktop\tiandaos\次元笔记本\第一卷 少年歌行.txt")
    output_dir = Path(r"C:\Users\shaoy\Desktop\tiandaos\tiandaotext\data\novel_split\次元笔记本\第一卷_少年歌行\chapters")

    print("=" * 60)
    print("《次元笔记本》第一卷 少年歌行 - 章节分析")
    print("=" * 60)

    # 读取源文件
    print(f"\n读取源文件: {source_file}")
    text = source_file.read_text(encoding='utf-8')
    print(f"源文件总长度: {len(text)} 字符")

    # 分割章节
    print("\n分割章节...")
    chapters = split_by_chapters(text)
    print(f"共发现 {len(chapters)} 个章节")

    # 处理第3-64章
    start_chapter = 3
    end_chapter = 64

    print(f"\n开始处理第{start_chapter}-{end_chapter}章...")
    print("-" * 60)

    success_count = 0
    error_count = 0

    for chapter_num, chapter_title, content in chapters:
        if chapter_num < start_chapter or chapter_num > end_chapter:
            continue

        # 检查是否已处理（存在spacetime_slice.json且无error.json）
        chapter_dir = output_dir / f"ch{chapter_num:02d}_{chapter_title[:30]}"
        if (chapter_dir / "spacetime_slice.json").exists() and not (chapter_dir / "error.json").exists():
            print(f"\n跳过已处理的第{chapter_num}章: {chapter_title[:30]}...")
            continue

        print(f"\n处理第{chapter_num}章: {chapter_title[:30]}...")
        print(f"  内容长度: {len(content)} 字符")

        # 调用API分析
        analysis = call_minimax_api(content, chapter_num, chapter_title)

        if "error" in analysis:
            print(f"  [错误] {analysis['error']}")
            error_count += 1
            # 保存错误信息以便后续重试
            error_dir = output_dir / f"ch{chapter_num:02d}_{chapter_title[:30]}"
            error_dir.mkdir(parents=True, exist_ok=True)
            (error_dir / "chapter_content.txt").write_text(content, encoding='utf-8')
            (error_dir / "error.json").write_text(json.dumps(analysis, ensure_ascii=False, indent=2), encoding='utf-8')
        else:
            # 保存结果
            save_chapter_analysis(chapter_num, chapter_title, content, analysis, output_dir)
            success_count += 1

        # 避免API限流
        import time
        time.sleep(1)

    print("\n" + "=" * 60)
    print(f"处理完成！成功: {success_count}, 失败: {error_count}")
    print("=" * 60)

if __name__ == "__main__":
    main()