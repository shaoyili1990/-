"""
Data formatting utilities
"""

from typing import Any, Dict, List, Optional
from datetime import datetime
from dataclasses import asdict


def format_datetime(dt: datetime, iso_format: bool = True) -> str:
    """
    Format datetime to string.
    
    Args:
        dt: Datetime object
        iso_format: Use ISO format if True
        
    Returns:
        Formatted datetime string
    """
    if dt is None:
        return None
    
    if iso_format:
        return dt.isoformat() + "Z"
    
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def format_memory_node(memory: Any) -> Dict:
    """
    Format a memory node for API response.
    
    Args:
        memory: MemoryNode instance
        
    Returns:
        Formatted dictionary
    """
    return {
        "id": memory.id,
        "memory_type": memory.memory_type.value if hasattr(memory.memory_type, 'value') else str(memory.memory_type),
        "content": memory.content,
        "timestamp": format_datetime(memory.timestamp) if hasattr(memory, 'timestamp') else None,
        "emotional_intensity": memory.emotional_intensity if hasattr(memory, 'emotional_intensity') else 0.0,
        "importance": memory.importance if hasattr(memory, 'importance') else 0.0,
        "strength": memory.strength if hasattr(memory, 'strength') else 0.0,
        "is_traumatic": memory.is_traumatic if hasattr(memory, 'is_traumatic') else False,
        "trauma_level": memory.trauma_level if hasattr(memory, 'trauma_level') else 0.0,
        "tags": list(memory.tags) if hasattr(memory, 'tags') and memory.tags else [],
        "access_count": memory.access_count if hasattr(memory, 'access_count') else 0
    }


def format_psychology_output(output: Any) -> Dict:
    """
    Format psychology engine output for API response.
    
    Args:
        output: PsychologyOutput instance
        
    Returns:
        Formatted dictionary
    """
    result = {
        "y_value": output.y_value if hasattr(output, 'y_value') else 0,
        "behavioral_tendency": output.behavioral_tendency if hasattr(output, 'behavioral_tendency') else "",
        "moral_adjustment": output.moral_adjustment if hasattr(output, 'moral_adjustment') else 0.0,
        "overflow_warning": output.overflow_warning if hasattr(output, 'overflow_warning') else False,
        "active_motivations": output.active_motivations if hasattr(output, 'active_motivations') else [],
        "triggered_memories": output.triggered_memories if hasattr(output, 'triggered_memories') else [],
        "messages": output.messages if hasattr(output, 'messages') else []
    }
    
    # Format emotional state
    if hasattr(output, 'emotional_state') and output.emotional_state:
        emotional = output.emotional_state
        result["emotional_state"] = {
            "valence": emotional.valence if hasattr(emotional, 'valence') else 0.0,
            "arousal": emotional.arousal if hasattr(emotional, 'arousal') else 0.5,
            "dominance": emotional.dominance if hasattr(emotional, 'dominance') else 0.5,
            "intensity": emotional.intensity if hasattr(emotional, 'intensity') else 0.5
        }
    else:
        result["emotional_state"] = {
            "valence": 0.0,
            "arousal": 0.5,
            "dominance": 0.5,
            "intensity": 0.5
        }
    
    return result


def format_character_profile(profile: Any) -> Dict:
    """
    Format character profile for API response.
    
    Args:
        profile: CharacterProfile instance
        
    Returns:
        Formatted dictionary
    """
    result = {}
    
    # Basic info
    if hasattr(profile, 'info') and profile.info:
        info = profile.info
        result["info"] = {
            "id": info.id,
            "name": info.name,
            "description": info.description if hasattr(info, 'description') else "",
            "tags": list(info.tags) if hasattr(info, 'tags') and info.tags else [],
            "avatar_url": info.avatar_url if hasattr(info, 'avatar_url') else None,
            "base_y": info.base_y if hasattr(info, 'base_y') else 50,
            "mbti_type": info.mbti_type if hasattr(info, 'mbti_type') else "INTJ",
            "trauma_level": info.trauma_level if hasattr(info, 'trauma_level') else 0.0,
            "created_at": format_datetime(info.created_at) if hasattr(info, 'created_at') and info.created_at else None,
            "updated_at": format_datetime(info.updated_at) if hasattr(info, 'updated_at') and info.updated_at else None
        }
    
    # Y value system
    if hasattr(profile, 'y_system') and profile.y_system:
        y_sys = profile.y_system
        result["y_value"] = {
            "current": y_sys.Y if hasattr(y_sys, 'Y') else 50,
            "baseline": y_sys.state.baseline_y if hasattr(y_sys, 'state') else 50,
            "is_compensating": y_sys.state.is_compensating if hasattr(y_sys, 'state') else False,
            "threshold": y_sys.get_threshold() if hasattr(y_sys, 'get_threshold') else 20
        }
    
    # MBTI system
    if hasattr(profile, 'mbti_system') and profile.mbti_system:
        mbti = profile.mbti_system
        result["mbti"] = {
            "type": mbti.mbti_type if hasattr(mbti, 'mbti_type') else "INTJ",
            "reaction_style": mbti.get_reaction_style() if hasattr(mbti, 'get_reaction_style') else ""
        }
    
    return result


def sanitize_string(text: str, max_length: int = 10000) -> str:
    """
    Sanitize a string input.
    
    Args:
        text: Input text
        max_length: Maximum allowed length
        
    Returns:
        Sanitized string
    """
    if not text:
        return ""
    
    # Remove null bytes
    text = text.replace('\x00', '')
    
    # Truncate if too long
    if len(text) > max_length:
        text = text[:max_length]
    
    return text.strip()
