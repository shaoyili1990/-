"""
Input validation utilities
"""

from typing import Any, Dict, List, Optional, Tuple
import re


def validate_character_data(data: Dict[str, Any]) -> Tuple[bool, Dict[str, List[str]]]:
    """
    Validate character creation/update data.
    
    Args:
        data: Character data dictionary
        
    Returns:
        Tuple of (is_valid, errors_dict)
    """
    errors: Dict[str, List[str]] = {}
    
    # Name validation
    if "name" not in data or not data["name"]:
        errors.setdefault("name", []).append("Name is required")
    elif len(data["name"]) > 100:
        errors.setdefault("name", []).append("Name must be 100 characters or less")
    
    # Base Y validation
    if "base_y" in data:
        base_y = data["base_y"]
        if not isinstance(base_y, int):
            errors.setdefault("base_y", []).append("Base Y must be an integer")
        elif not (1 <= base_y <= 100):
            errors.setdefault("base_y", []).append("Base Y must be between 1 and 100")
    
    # MBTI validation
    if "mbti_type" in data:
        mbti = data["mbti_type"]
        valid_mbti = [
            "INTJ", "INTP", "ENTJ", "ENTP",
            "INFJ", "INFP", "ENFJ", "ENFP",
            "ISTJ", "ISFJ", "ESTJ", "ESFJ",
            "ISTP", "ISFP", "ESTP", "ESFP"
        ]
        if mbti not in valid_mbti:
            errors.setdefault("mbti_type", []).append(
                f"MBTI type must be one of: {', '.join(valid_mbti)}"
            )
    
    # Tags validation
    if "tags" in data:
        tags = data["tags"]
        if not isinstance(tags, list):
            errors.setdefault("tags", []).append("Tags must be a list")
        elif any(not isinstance(t, str) for t in tags):
            errors.setdefault("tags", []).append("All tags must be strings")
        elif len(tags) > 20:
            errors.setdefault("tags", []).append("Maximum 20 tags allowed")
    
    # Description validation
    if "description" in data and len(data["description"]) > 5000:
        errors.setdefault("description", []).append("Description must be 5000 characters or less")
    
    # Trauma level validation
    if "trauma_level" in data:
        trauma = data["trauma_level"]
        if not isinstance(trauma, (int, float)):
            errors.setdefault("trauma_level", []).append("Trauma level must be a number")
        elif not (0.0 <= trauma <= 1.0):
            errors.setdefault("trauma_level", []).append("Trauma level must be between 0.0 and 1.0")
    
    return len(errors) == 0, errors


def validate_memory_data(data: Dict[str, Any]) -> Tuple[bool, Dict[str, List[str]]]:
    """
    Validate memory creation data.
    
    Args:
        data: Memory data dictionary
        
    Returns:
        Tuple of (is_valid, errors_dict)
    """
    errors: Dict[str, List[str]] = {}
    
    # Content validation
    if "content" not in data or not data["content"]:
        errors.setdefault("content", []).append("Content is required")
    elif len(data["content"]) > 10000:
        errors.setdefault("content", []).append("Content must be 10000 characters or less")
    
    # Memory type validation
    if "memory_type" in data:
        valid_types = ["episodic", "procedural", "semantic", "emotional", "sensory"]
        if data["memory_type"] not in valid_types:
            errors.setdefault("memory_type", []).append(
                f"Memory type must be one of: {', '.join(valid_types)}"
            )
    
    # Emotional intensity validation
    if "emotional_intensity" in data:
        intensity = data["emotional_intensity"]
        if not isinstance(intensity, (int, float)):
            errors.setdefault("emotional_intensity", []).append("Must be a number")
        elif not (0.0 <= intensity <= 1.0):
            errors.setdefault("emotional_intensity", []).append("Must be between 0.0 and 1.0")
    
    # Importance validation
    if "importance" in data:
        importance = data["importance"]
        if not isinstance(importance, (int, float)):
            errors.setdefault("importance", []).append("Must be a number")
        elif not (0.0 <= importance <= 1.0):
            errors.setdefault("importance", []).append("Must be between 0.0 and 1.0")
    
    # Trauma level validation
    if "trauma_level" in data:
        trauma = data["trauma_level"]
        if not isinstance(trauma, (int, float)):
            errors.setdefault("trauma_level", []).append("Must be a number")
        elif not (0.0 <= trauma <= 1.0):
            errors.setdefault("trauma_level", []).append("Must be between 0.0 and 1.0")
    
    return len(errors) == 0, errors


def validate_situation(situation: str) -> Tuple[bool, Optional[str]]:
    """
    Validate a situation/context string.
    
    Args:
        situation: The situation string to validate
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not situation:
        return False, "Situation cannot be empty"
    
    if len(situation) > 10000:
        return False, "Situation must be 10000 characters or less"
    
    return True, None


def validate_uuid(uuid_str: str) -> bool:
    """
    Validate UUID format.
    
    Args:
        uuid_str: String to validate
        
    Returns:
        True if valid UUID format
    """
    uuid_pattern = re.compile(
        r'^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$|^[a-f0-9]{8}$',
        re.IGNORECASE
    )
    return bool(uuid_pattern.match(uuid_str))
