"""
Character Card Parser Module

Handles parsing and conversion of SillyTavern character cards
to Tiandao system format.
"""

import json
import re
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

# Import tiandao core
from tiandao.core.profile import CharacterInfo
from tiandao.core.mbti import MBTISystem


@dataclass
class ParsedCharacterCard:
    """Parsed character card data"""
    name: str
    description: str = ""
    personality: str = ""
    scenario: str = ""
    first_message: str = ""
    avatar_url: Optional[str] = None
    tags: List[str] = field(default_factory=list)
    creator_notes: str = ""
    system_prompt: str = ""
    
    # Tiandao specific
    base_y: int = 50
    mbti_type: str = "INTJ"
    trauma_level: float = 0.0
    
    # Raw data
    raw_data: Dict = field(default_factory=dict)


class CharacterCardParser:
    """
    Parser for SillyTavern character cards.
    
    Supports formats:
    - JSON (SillyTavern v1.0+)
    - TavernAI v2 format
    - Legacy text format
    """
    
    # Tag patterns for MBTI inference
    TAG_TO_MBTI = {
        "理性": ["INTJ", "INTP", "ENTJ", "ENTP"],
        "内耗": ["INTJ", "INFJ", "INFP"],
        "独立": ["INTJ", "INTP", "ISTP"],
        "完美主义": ["INTJ"],
        "战略": ["INTJ", "ENTJ"],
        "逻辑": ["INTJ", "INTP", "ISTP", "ESTP"],
        "分析": ["INTP", "ISTP", "INTJ"],
        "好奇": ["INTP", "ENFP", "ENTP"],
        "领导": ["ENTJ", "ENFJ", "ESTJ"],
        "果断": ["ENTJ", "ESTJ"],
        "自信": ["ENTJ", "ESTP", "ESFP"],
        "指挥": ["ENTJ", "ESTJ"],
        "创意": ["ENTP", "ENFP", "INFJ"],
        "辩论": ["ENTP", "ENTJ"],
        "机智": ["ENTP", "ESTP"],
        "共情": ["INFJ", "INFP", "ENFJ", "ISFJ"],
        "理想": ["INFJ", "INFP", "ENFJ"],
        "敏感": ["INFP", "ISFP", "INFJ"],
        "洞察": ["INFJ", "INTJ"],
        "神秘": ["INFJ", "INTJ", "INTP"],
        "浪漫": ["INFP", "ENFP", "ISFP"],
        "内敛": ["INFJ", "INFP", "ISFP", "ISTP"],
        "魅力": ["ENFJ", "ENFP", "ESFP"],
        "热情": ["ENFJ", "ENFP", "ESFP", "ESTP"],
        "关怀": ["ENFJ", "ESFJ", "ISFJ"],
        "说服": ["ENFJ", "ENTP"],
        "自由": ["ENFP", "ISFP"],
        "激励": ["ENFJ", "ENFP"],
        "可靠": ["ISTJ", "ISFJ", "ESTJ"],
        "务实": ["ISTJ", "ISFJ", "ESTJ", "ISTP", "ESTP"],
        "传统": ["ISTJ", "ISFJ", "ESTJ", "ESFJ"],
        "负责": ["ISTJ", "ISFJ", "ESTJ", "ENFJ"],
        "稳定": ["ISTJ", "ISFJ"],
        "忠诚": ["ISFJ", "ISFP", "ISTJ"],
        "守护": ["ISFJ", "ISFP"],
        "组织": ["ESTJ", "ISTJ"],
        "管理": ["ESTJ", "ENTJ"],
        "和谐": ["ESFJ", "ENFJ"],
        "社交": ["ESFJ", "ENFP", "ESTP", "ESFP"],
        "动手": ["ISTP", "ESTP"],
        "冷静": ["ISTP", "INTP", "ESTP"],
        "艺术": ["ISFP", "ESFP", "INFP"],
        "审美": ["ISFP", "INFP", "ESFP"],
        "行动": ["ESTP", "ESFP"],
        "适应": ["ESTP", "ESFP", "ENTP"],
        "活力": ["ESFP", "ESTP", "ENFP"],
        "表演": ["ESFP", "ENFP"],
        "多变": ["ENTP", "ENFP", "ISFP"]
    }
    
    # Trauma indicators
    TRAUMA_KEYWORDS = [
        "创伤", " PTSD", "阴影", "痛苦", "失去", "死亡",
        "背叛", "抛弃", "孤独", "恐惧", "噩梦", "崩溃",
        "trauma", "ptsd", "scar", "lost", "death", "betrayal"
    ]
    
    def __init__(self):
        self.current_card: Optional[ParsedCharacterCard] = None
    
    def parse_json(self, json_data: str | Dict) -> ParsedCharacterCard:
        """
        Parse JSON format character card.
        
        Args:
            json_data: JSON string or dict
            
        Returns:
            ParsedCharacterCard instance
        """
        if isinstance(json_data, str):
            data = json.loads(json_data)
        else:
            data = json_data
        
        # Handle different JSON formats
        if "spec" in data:
            return self._parse_sillytavern_v1(data)
        elif "data" in data:
            return self._parse_tavernai_v2(data)
        else:
            return self._parse_legacy(data)
    
    def _parse_sillytavern_v1(self, data: Dict) -> ParsedCharacterCard:
        """Parse SillyTavern v1.0+ format"""
        spec = data.get("spec", {})
        name = spec.get("name", "Unknown")
        
        # Extract tags
        tags = []
        if "tags" in spec:
            tags = spec["tags"] if isinstance(spec["tags"], list) else []
        elif "char persona" in data:
            tags = self._extract_tags_from_text(data["char persona"])
        
        # MBTI inference
        mbti, confidence = self._infer_mbti(tags)
        
        # Trauma detection
        trauma_level = self._detect_trauma(data.get("description", ""), data.get("char persona", ""))
        
        # Extract Y-value hints from description
        base_y = self._extract_y_hint(data.get("description", ""), mbti)
        
        card = ParsedCharacterCard(
            name=name,
            description=data.get("description", ""),
            personality=data.get("char persona", ""),
            scenario=data.get("scenario", ""),
            first_message=data.get("first_message", data.get("talk_syllogism", "")),
            avatar_url=data.get("avatar"),
            tags=tags,
            creator_notes=data.get("creator notes", ""),
            system_prompt=data.get("system prompt", ""),
            base_y=base_y,
            mbti_type=mbti,
            trauma_level=trauma_level,
            raw_data=data
        )
        
        self.current_card = card
        return card
    
    def _parse_tavernai_v2(self, data: Dict) -> ParsedCharacterCard:
        """Parse TavernAI v2 format"""
        inner = data.get("data", {})
        name = inner.get("name", "Unknown")
        
        tags = inner.get("tags", [])
        mbti, _ = self._infer_mbti(tags)
        trauma_level = self._detect_trauma(inner.get("description", ""), inner.get("personality", ""))
        
        card = ParsedCharacterCard(
            name=name,
            description=inner.get("description", ""),
            personality=inner.get("personality", ""),
            scenario=inner.get("scenario", ""),
            first_message=inner.get("firstMes", ""),
            avatar_url=data.get("avatar"),
            tags=tags,
            base_y=50,  # Default
            mbti_type=mbti,
            trauma_level=trauma_level,
            raw_data=data
        )
        
        self.current_card = card
        return card
    
    def _parse_legacy(self, data: Dict) -> ParsedCharacterCard:
        """Parse legacy format"""
        name = data.get("name", data.get("char_name", "Unknown"))
        
        text_for_tags = " ".join([
            data.get("description", ""),
            data.get("personality", ""),
            data.get("char_persona", "")
        ])
        
        tags = self._extract_tags_from_text(text_for_tags)
        mbti, _ = self._infer_mbti(tags)
        trauma_level = self._detect_trauma(text_for_tags, "")
        
        card = ParsedCharacterCard(
            name=name,
            description=data.get("description", ""),
            personality=data.get("personality", data.get("char_persona", "")),
            scenario=data.get("scenario", ""),
            first_message=data.get("first_message", ""),
            tags=tags,
            base_y=50,
            mbti_type=mbti,
            trauma_level=trauma_level,
            raw_data=data
        )
        
        self.current_card = card
        return card
    
    def _extract_tags_from_text(self, text: str) -> List[str]:
        """Extract potential tags from text"""
        if not text:
            return []
        
        # Look for bracketed tags
        tag_pattern = r'\[([^\]]+)\]'
        found_tags = re.findall(tag_pattern, text)
        
        # Clean up
        tags = []
        for tag in found_tags:
            tag = tag.strip()
            if tag and len(tag) < 50:
                tags.append(tag)
        
        return tags
    
    def _infer_mbti(self, tags: List[str]) -> Tuple[str, float]:
        """
        Infer MBTI type from tags.
        
        Returns:
            Tuple of (mbti_type, confidence)
        """
        if not tags:
            return "INTJ", 0.0
        
        # Score each MBTI type
        scores: Dict[str, int] = {}
        
        for tag in tags:
            tag_lower = tag.lower()
            for keyword, types in self.TAG_TO_MBTI.items():
                if keyword in tag_lower:
                    for mbti in types:
                        scores[mbti] = scores.get(mbti, 0) + 1
        
        if not scores:
            return "INTJ", 0.0
        
        # Get highest scoring type
        best_type = max(scores.items(), key=lambda x: x[1])
        confidence = min(best_type[1] / 3.0, 1.0)  # Normalize to 0-1
        
        return best_type[0], confidence
    
    def _detect_trauma(self, description: str, personality: str) -> float:
        """
        Detect trauma level from text.
        
        Returns:
            Trauma level 0.0 - 1.0
        """
        text = f"{description} {personality}".lower()
        
        count = 0
        for keyword in self.TRAUMA_KEYWORDS:
            if keyword.lower() in text:
                count += 1
        
        # Normalize to 0-1 range
        if count >= 5:
            return 0.8
        elif count >= 3:
            return 0.5
        elif count >= 1:
            return 0.2
        return 0.0
    
    def _extract_y_hint(self, text: str, mbti: str) -> int:
        """
        Extract Y-value hints from description.
        
        Looks for explicit Y-value mentions or strong trait indicators.
        """
        # Check for explicit Y-value
        y_pattern = r'[Yy]\s*[=:]\s*(\d+)'
        match = re.search(y_pattern, text)
        if match:
            y = int(match.group(1))
            return max(1, min(100, y))
        
        # MBTI-based default
        mbti_system = MBTISystem(mbti)
        return 50 + mbti_system.weights.base_y_offset
    
    def to_character_info(self, card: Optional[ParsedCharacterCard] = None) -> CharacterInfo:
        """
        Convert parsed card to CharacterInfo.
        
        Args:
            card: Parsed card (uses current_card if None)
            
        Returns:
            CharacterInfo instance
        """
        card = card or self.current_card
        
        if not card:
            raise ValueError("No character card available")
        
        return CharacterInfo(
            id=self._generate_id(card.name),
            name=card.name,
            description=card.description,
            tags=card.tags,
            avatar_url=card.avatar_url,
            base_y=card.base_y,
            mbti_type=card.mbti_type,
            trauma_level=card.trauma_level,
            created_at=datetime.now().isoformat(),
            updated_at=datetime.now().isoformat()
        )
    
    def _generate_id(self, name: str) -> str:
        """Generate a stable ID from name"""
        import hashlib
        hash_val = hashlib.md5(name.encode()).hexdigest()[:8]
        return f"char_{hash_val}"
    
    def to_tiandao_format(self, card: Optional[ParsedCharacterCard] = None) -> Dict:
        """
        Convert card to full Tiandao system format.
        
        Args:
            card: Parsed card (uses current_card if None)
            
        Returns:
            Dictionary ready for CharacterProfile creation
        """
        card = card or self.current_card
        
        if not card:
            raise ValueError("No character card available")
        
        info = self.to_character_info(card)
        
        return {
            "character_id": info.id,
            "name": info.name,
            "base_y": info.base_y,
            "mbti_type": info.mbti_type,
            "tags": info.tags,
            "description": info.description,
            "trauma_level": info.trauma_level,
            "mbti_profile": MBTISystem(card.mbti_type).get_full_profile(),
            "parsing_metadata": {
                "mbti_confidence": self._infer_mbti(card.tags)[1],
                "trauma_detected": card.trauma_level > 0,
                "original_format": self._detect_format(card.raw_data)
            }
        }
    
    def _detect_format(self, data: Dict) -> str:
        """Detect original card format"""
        if "spec" in data:
            return "sillytavern_v1"
        elif "data" in data:
            return "tavernai_v2"
        return "legacy"


def parse_character_card(json_data: str | Dict) -> ParsedCharacterCard:
    """
    Convenience function to parse a character card.
    
    Args:
        json_data: JSON string or dict
        
    Returns:
        ParsedCharacterCard instance
    """
    parser = CharacterCardParser()
    return parser.parse_json(json_data)
