"""
Character Management API Module

REST API endpoints for character CRUD operations
integrating with the Tiandao character profile system.
"""

from typing import Any, Dict, List, Optional
from flask import Blueprint, request
from functools import wraps
import logging
import uuid
from datetime import datetime

# Import tiandao core
from tiandao.core.profile import CharacterProfile
from tiandao.core.memory import MemoryType
from tiandao.core.motivation import InstinctType
from tiandao.core.mbti import MBTISystem

# Import utilities
from utils.responses import success_response, error_response, validation_error_response, paginated_response
from utils.validators import validate_character_data, validate_uuid

logger = logging.getLogger(__name__)

# Create blueprint
character_bp = Blueprint('character', __name__, url_prefix='/api/v1/characters')

# In-memory character storage (replace with database in production)
_characters: Dict[str, CharacterProfile] = {}


def handle_errors(f):
    """Decorator for error handling"""
    from werkzeug.exceptions import BadRequest
    @wraps(f)
    def decorated(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except BadRequest as e:
            logger.warning(f"Bad request: {e}")
            return error_response(str(e.description) if hasattr(e, 'description') else "Invalid request", status_code=400, error_code="BAD_REQUEST")
        except ValueError as e:
            logger.warning(f"Validation error: {e}")
            return error_response(str(e), status_code=422, error_code="VALIDATION_ERROR")
        except KeyError as e:
            logger.warning(f"Resource not found: {e}")
            return error_response(f"Resource not found: {e}", status_code=404)
        except Exception as e:
            logger.error(f"Unexpected error: {e}", exc_info=True)
            return error_response("Internal server error", status_code=500)
    return decorated


def get_character_or_404(character_id: str) -> CharacterProfile:
    """Get character by ID or raise 404"""
    if character_id not in _characters:
        raise KeyError(character_id)
    return _characters[character_id]


def serialize_character(profile: CharacterProfile) -> Dict:
    """Serialize character profile for API response"""
    return profile.get_full_profile()


# ========== Character CRUD Endpoints ==========

@character_bp.route('', methods=['GET'])
@handle_errors
def list_characters():
    """
    List all characters with pagination.
    
    Query params:
    - page: int (default: 1)
    - per_page: int (default: 20)
    - search: str - Search by name
    - tags: str - Comma-separated tags to filter
    """
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    search = request.args.get('search', '').lower()
    tags_filter = request.args.get('tags', '')
    
    # Filter characters
    filtered = []
    for char in _characters.values():
        # Name search
        if search and search not in char.info.name.lower():
            continue
        
        # Tags filter
        if tags_filter:
            required_tags = set(tags_filter.split(','))
            if not required_tags.intersection(set(char.info.tags)):
                continue
        
        filtered.append(serialize_character(char))
    
    total = len(filtered)
    
    # Paginate
    start = (page - 1) * per_page
    end = start + per_page
    page_items = filtered[start:end]
    
    return paginated_response(
        items=page_items,
        total=total,
        page=page,
        per_page=per_page,
        message=f"Retrieved {len(page_items)} characters"
    )


@character_bp.route('', methods=['POST'])
@handle_errors
def create_new_character():
    """
    Create a new character.
    
    Request body:
    {
        "name": str (required),
        "description": str,
        "tags": [str],
        "avatar_url": str,
        "base_y": int (1-100),
        "mbti_type": str,
        "trauma_level": float (0-1),
        "character_card": {} - Optional SillyTavern character card JSON
    }
    """
    data = request.get_json()
    
    if not data:
        return error_response("Request body is required", status_code=400)
    
    is_valid, errors = validate_character_data(data)
    if not is_valid:
        return validation_error_response(errors)
    
    # Check character limit
    from config import config
    if len(_characters) >= config.tiandao.MAX_CHARACTERS:
        return error_response(
            f"Maximum character limit ({config.tiandao.MAX_CHARACTERS}) reached",
            status_code=400
        )
    
    # Generate ID
    character_id = data.get('id') or str(uuid.uuid4())[:8]
    
    # Check for duplicate
    if character_id in _characters:
        return error_response(f"Character with ID '{character_id}' already exists", status_code=409)
    
    # Handle character card import
    if 'character_card' in data:
        from character_manager import CharacterCardParser
        parser = CharacterCardParser()
        parsed = parser.parse_json(data['character_card'])
        character_id = parsed.name.lower().replace(' ', '_')[:16]
        
        profile = CharacterProfile.create(
            character_id=character_id,
            name=parsed.name,
            base_y=parsed.base_y,
            mbti_type=parsed.mbti_type,
            tags=parsed.tags + data.get('tags', []),
            description=parsed.description or data.get('description', '')
        )
    else:
        # Create from scratch
        profile = CharacterProfile.create(
            character_id=character_id,
            name=data['name'],
            base_y=data.get('base_y', 50),
            mbti_type=data.get('mbti_type', 'INTJ'),
            tags=data.get('tags', []),
            description=data.get('description', '')
        )
    
    # Set trauma level
    if 'trauma_level' in data:
        profile.info.trauma_level = data['trauma_level']
        profile.author_system.generate_character_constraint(
            profile.info.mbti_type,
            profile.info.trauma_level
        )
    
    # Set avatar
    if 'avatar_url' in data:
        profile.info.avatar_url = data['avatar_url']
    
    # Set timestamps
    now = datetime.now().isoformat()
    profile.info.created_at = now
    profile.info.updated_at = now
    
    _characters[character_id] = profile
    
    logger.info(f"Created character: {character_id}")
    
    return success_response(
        data=serialize_character(profile),
        message=f"Character '{profile.info.name}' created",
        status_code=201
    )


@character_bp.route('/<character_id>', methods=['GET'])
@handle_errors
def get_character(character_id: str):
    """
    Get a character by ID.
    """
    profile = get_character_or_404(character_id)
    
    return success_response(
        data=serialize_character(profile),
        message=f"Character '{profile.info.name}' retrieved"
    )


@character_bp.route('/<character_id>', methods=['PUT'])
@handle_errors
def update_character(character_id: str):
    """
    Update a character.
    
    Request body:
    {
        "name": str,
        "description": str,
        "tags": [str],
        "avatar_url": str,
        "base_y": int,
        "mbti_type": str,
        "trauma_level": float
    }
    """
    data = request.get_json()
    
    if not data:
        return error_response("Request body is required", status_code=400)
    
    profile = get_character_or_404(character_id)
    
    # Validate
    is_valid, errors = validate_character_data(data)
    if not is_valid:
        return validation_error_response(errors)
    
    # Update fields
    if 'name' in data:
        profile.info.name = data['name']
    
    if 'description' in data:
        profile.info.description = data['description']
    
    if 'tags' in data:
        profile.info.tags = data['tags']
    
    if 'avatar_url' in data:
        profile.info.avatar_url = data['avatar_url']
    
    if 'base_y' in data:
        profile.info.base_y = data['base_y']
        profile.y_system.state.current_y = data['base_y']
        profile.y_system.set_baseline(data['base_y'])
    
    if 'mbti_type' in data:
        profile.info.mbti_type = data['mbti_type']
        # Reinitialize MBTI system
        from tiandao.core.mbti import MBTISystem
        profile.mbti_system = MBTISystem(data['mbti_type'])
    
    if 'trauma_level' in data:
        profile.info.trauma_level = data['trauma_level']
        profile.author_system.generate_character_constraint(
            profile.info.mbti_type,
            profile.info.trauma_level
        )
    
    profile.info.updated_at = datetime.now().isoformat()
    
    logger.info(f"Updated character: {character_id}")
    
    return success_response(
        data=serialize_character(profile),
        message=f"Character '{profile.info.name}' updated"
    )


@character_bp.route('/<character_id>', methods=['DELETE'])
@handle_errors
def delete_character(character_id: str):
    """
    Delete a character.
    """
    profile = get_character_or_404(character_id)
    name = profile.info.name
    
    del _characters[character_id]
    
    logger.info(f"Deleted character: {character_id}")
    
    return success_response(
        data={"id": character_id},
        message=f"Character '{name}' deleted"
    )


# ========== Character Actions ==========

@character_bp.route('/<character_id>/calculate', methods=['POST'])
@handle_errors
def calculate_character_response(character_id: str):
    """
    Calculate character response to a situation.
    
    Request body:
    {
        "situation": str,
        "context": {},
        "interaction_y": int
    }
    """
    data = request.get_json()
    
    if not data or 'situation' not in data:
        return error_response("Situation is required", status_code=400)
    
    profile = get_character_or_404(character_id)
    
    result = profile.calculate_response(
        situation=data['situation'],
        context=data.get('context'),
        interaction_y=data.get('interaction_y')
    )
    
    return success_response(
        data={
            "character_id": character_id,
            "situation": data['situation'],
            "response": result
        },
        message="Character response calculated"
    )


@character_bp.route('/<character_id>/memories', methods=['GET'])
@handle_errors
def get_character_memories(character_id: str):
    """
    Get all memories for a character.
    
    Query params:
    - type: str - Filter by memory type
    - limit: int
    """
    profile = get_character_or_404(character_id)
    
    memory_type = request.args.get('type')
    limit = request.args.get('limit', 100, type=int)
    
    if memory_type:
        memory_type_enum = MemoryType(memory_type)
        summary = profile.memory_system.get_memory_summary(memory_type_enum)
    else:
        summary = profile.memory_system.get_memory_summary()
    
    return success_response(
        data={
            "character_id": character_id,
            "summary": summary,
            "memories": [
                {
                    "id": m.id,
                    "content": m.content,
                    "type": m.memory_type.value,
                    "strength": m.strength,
                    "is_traumatic": m.is_traumatic
                }
                for m in list(profile.memory_system.memories.values())[:limit]
            ]
        },
        message="Character memories retrieved"
    )


@character_bp.route('/<character_id>/memories', methods=['POST'])
@handle_errors
def add_character_memory(character_id: str):
    """
    Add a memory to a character.
    
    Request body:
    {
        "content": str,
        "memory_type": str,
        "emotional_intensity": float,
        "importance": float,
        "is_traumatic": bool,
        "trauma_level": float,
        "triggers": [str]
    }
    """
    data = request.get_json()
    
    if not data or 'content' not in data:
        return error_response("Content is required", status_code=400)
    
    profile = get_character_or_404(character_id)
    
    memory_type = MemoryType(data.get('memory_type', 'episodic'))
    
    memory = profile.add_memory(
        content=data['content'],
        memory_type=memory_type,
        emotional_intensity=data.get('emotional_intensity', 0.5),
        importance=data.get('importance', 0.5),
        is_traumatic=data.get('is_traumatic', False),
        trauma_level=data.get('trauma_level', 0.0),
        triggers=data.get('triggers', [])
    )
    
    return success_response(
        data={
            "character_id": character_id,
            "memory_id": memory.id,
            "memory_type": memory.memory_type.value
        },
        message="Memory added to character",
        status_code=201
    )


@character_bp.route('/<character_id>/memories/retrieve', methods=['POST'])
@handle_errors
def retrieve_character_memories(character_id: str):
    """
    Retrieve relevant memories for a character.
    
    Request body:
    {
        "query": str,
        "memory_types": [str],
        "limit": int
    }
    """
    data = request.get_json()
    
    if not data or 'query' not in data:
        return error_response("Query is required", status_code=400)
    
    profile = get_character_or_404(character_id)
    
    memory_types = None
    if 'memory_types' in data:
        memory_types = [MemoryType(t) for t in data['memory_types']]
    
    results = profile.retrieve_memories(
        query=data['query'],
        memory_types=memory_types,
        limit=data.get('limit', 10)
    )
    
    return success_response(
        data={
            "character_id": character_id,
            "query": data['query'],
            "results": results
        },
        message=f"Retrieved {len(results)} relevant memories"
    )


@character_bp.route('/<character_id>/ptsd', methods=['POST'])
@handle_errors
def check_character_ptsd(character_id: str):
    """
    Check PTSD triggers for a character.
    
    Request body:
    {
        "event": str
    }
    """
    data = request.get_json()
    
    if not data or 'event' not in data:
        return error_response("Event is required", status_code=400)
    
    profile = get_character_or_404(character_id)
    
    result = profile.check_ptsd(event=data['event'])
    
    return success_response(
        data={
            "character_id": character_id,
            "event": data['event'],
            "ptsd_result": result
        },
        message="PTSD check completed"
    )


@character_bp.route('/<character_id>/validate-behavior', methods=['POST'])
@handle_errors
def validate_character_behavior(character_id: str):
    """
    Validate if a behavior is appropriate for the character.
    
    Request body:
    {
        "behavior": str
    }
    """
    data = request.get_json()
    
    if not data or 'behavior' not in data:
        return error_response("Behavior is required", status_code=400)
    
    profile = get_character_or_404(character_id)
    
    result = profile.validate_behavior(data['behavior'])
    
    return success_response(
        data={
            "character_id": character_id,
            "behavior": data['behavior'],
            "validation": result
        },
        message="Behavior validation completed"
    )


@character_bp.route('/<character_id>/activate-instinct', methods=['POST'])
@handle_errors
def activate_character_instinct(character_id: str):
    """
    Activate an instinct for a character.
    
    Request body:
    {
        "instinct": str,
        "intensity_modifier": float
    }
    """
    data = request.get_json()
    
    if not data or 'instinct' not in data:
        return error_response("Instinct is required", status_code=400)
    
    try:
        instinct = InstinctType(data['instinct'])
    except ValueError:
        valid = [i.value for i in InstinctType]
        return error_response(f"Invalid instinct. Valid: {valid}", status_code=422)
    
    profile = get_character_or_404(character_id)
    
    result = profile.activate_instinct(
        instinct,
        data.get('intensity_modifier', 1.0)
    )
    
    return success_response(
        data={
            "character_id": character_id,
            "instinct_activation": result
        },
        message=f"Instinct '{data['instinct']}' activated"
    )


@character_bp.route('/<character_id>/y-value', methods=['GET'])
@handle_errors
def get_character_y_value(character_id: str):
    """
    Get character's current Y-value state.
    """
    profile = get_character_or_404(character_id)
    
    return success_response(
        data={
            "character_id": character_id,
            "y_value": profile.y_system.get_state_report()
        },
        message="Character Y-value retrieved"
    )


@character_bp.route('/<character_id>/y-value/trigger', methods=['POST'])
@handle_errors
def trigger_character_y_event(character_id: str):
    """
    Trigger a Y-value event for a character.
    
    Request body:
    {
        "event_type": "breakthrough|ptsd|major_event|emotional_extreme",
        "value": int,
        "event_subtype": str,
        "emotion_type": str
    }
    """
    data = request.get_json()
    
    if not data or 'event_type' not in data:
        return error_response("Event type is required", status_code=400)
    
    profile = get_character_or_404(character_id)
    event_type = data['event_type']
    
    if event_type == 'breakthrough':
        result = profile.y_system.trigger_breakthrough(data.get('value', 70))
    elif event_type == 'ptsd':
        result = profile.y_system.trigger_ptsd(data.get('value', 70))
    elif event_type == 'major_event':
        result = profile.y_system.trigger_major_event(
            data.get('event_subtype', 'trauma'),
            data.get('intensity', 1)
        )
    elif event_type == 'emotional_extreme':
        result = profile.y_system.trigger_emotional_extreme(
            data.get('emotion_type', 'guilt')
        )
    else:
        return error_response(f"Unknown event type: {event_type}", status_code=422)
    
    return success_response(
        data={
            "character_id": character_id,
            "event": result.message,
            "old_y": result.old_y,
            "new_y": result.new_y,
            "triggered": result.triggered
        },
        message=f"Y-value event '{event_type}' processed"
    )


@character_bp.route('/<character_id>/profile', methods=['GET'])
@handle_errors
def get_full_character_profile(character_id: str):
    """
    Get the complete character profile.
    """
    profile = get_character_or_404(character_id)
    
    return success_response(
        data=profile.get_full_profile(),
        message="Full character profile retrieved"
    )


# ========== Bulk Operations ==========

@character_bp.route('/bulk', methods=['POST'])
@handle_errors
def bulk_create_characters():
    """
    Create multiple characters at once.
    
    Request body:
    {
        "characters": [
            {"name": str, ...},
            {"name": str, ...}
        ]
    }
    """
    data = request.get_json()
    
    if not data or 'characters' not in data:
        return error_response("Characters list is required", status_code=400)
    
    characters = data['characters']
    
    if len(characters) > 100:
        return error_response("Maximum 100 characters per bulk operation", status_code=400)
    
    created = []
    errors = []
    
    for i, char_data in enumerate(characters):
        try:
            # Validate
            is_valid, validation_errors = validate_character_data(char_data)
            if not is_valid:
                errors.append({"index": i, "errors": validation_errors})
                continue
            
            # Create
            character_id = str(uuid.uuid4())[:8]
            profile = CharacterProfile.create(
                character_id=character_id,
                name=char_data['name'],
                base_y=char_data.get('base_y', 50),
                mbti_type=char_data.get('mbti_type', 'INTJ'),
                tags=char_data.get('tags', []),
                description=char_data.get('description', '')
            )
            
            _characters[character_id] = profile
            created.append({
                "id": character_id,
                "name": profile.info.name
            })
        except Exception as e:
            errors.append({"index": i, "error": str(e)})
    
    return success_response(
        data={
            "created": created,
            "errors": errors,
            "total_created": len(created),
            "total_errors": len(errors)
        },
        message=f"Bulk operation completed: {len(created)} created, {len(errors)} errors",
        status_code=201 if created else 200
    )


# ========== Utility Endpoints ==========

@character_bp.route('/stats', methods=['GET'])
@handle_errors
def get_character_stats():
    """
    Get statistics about stored characters.
    """
    total = len(_characters)
    mbti_counts = {}
    avg_y = 0
    
    for profile in _characters.values():
        mbti = profile.info.mbti_type
        mbti_counts[mbti] = mbti_counts.get(mbti, 0) + 1
        avg_y += profile.y_system.Y
    
    avg_y = avg_y / total if total > 0 else 0
    
    return success_response(
        data={
            "total_characters": total,
            "mbti_distribution": mbti_counts,
            "average_y_value": round(avg_y, 1)
        },
        message="Character statistics retrieved"
    )


@character_bp.route('/import', methods=['POST'])
@handle_errors
def import_character_card():
    """
    Import a character from SillyTavern character card format.
    
    Request body:
    {
        "character_card": {} - SillyTavern character card JSON
    }
    """
    from character_manager import CharacterCardParser
    
    data = request.get_json()
    
    if not data or 'character_card' not in data:
        return error_response("Character card is required", status_code=400)
    
    parser = CharacterCardParser()
    parsed = parser.parse_json(data['character_card'])
    
    # Create profile
    character_id = parsed.name.lower().replace(' ', '_')[:16]
    
    if character_id in _characters:
        return error_response(f"Character '{character_id}' already exists", status_code=409)
    
    profile = CharacterProfile.create(
        character_id=character_id,
        name=parsed.name,
        base_y=parsed.base_y,
        mbti_type=parsed.mbti_type,
        tags=parsed.tags,
        description=parsed.description
    )
    
    profile.info.trauma_level = parsed.trauma_level
    profile.info.avatar_url = parsed.avatar_url
    profile.info.created_at = datetime.now().isoformat()
    profile.info.updated_at = datetime.now().isoformat()
    
    _characters[character_id] = profile
    
    return success_response(
        data={
            "character": serialize_character(profile),
            "import_metadata": parser.to_tiandao_format(parsed)['parsing_metadata']
        },
        message=f"Character card imported as '{profile.info.name}'",
        status_code=201
    )
