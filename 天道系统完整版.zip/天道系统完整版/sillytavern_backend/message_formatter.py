"""
Message Formatter Module

Formats AI responses using Tiandao psychological context.
Applies emotional coloring, behavioral tendencies, and
author constraints to message generation.
"""

from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass
import random


@dataclass
class MessageContext:
    """Context for message formatting"""
    speaker_id: str
    listener_id: Optional[str] = None
    situation: str = ""
    emotional_intensity: float = 0.5
    is_dialogue: bool = True
    narrative_mode: str = "first_person"  # first_person, third_person, limited


@dataclass
class FormattedMessage:
    """A formatted message with Tiandao context"""
    content: str
    emotional_coloring: Dict[str, float]
    behavior_tags: List[str]
    tiandao_hints: Dict[str, Any]
    raw: bool = False


class MessageFormatter:
    """
    Message formatter using Tiandao psychological engine.
    
    Features:
    1. Emotional coloring based on seven emotions
    2. Behavioral tendency application
    3. Author constraint integration
    4. Narrative mode handling
    """
    
    # Emotional keywords for coloring
    EMOTION_KEYWORDS = {
        "joy": ["开心", "高兴", "快乐", "欢笑", "兴奋", "欣喜"],
        "anger": ["愤怒", "生气", "恼火", "火大", "不满", "激动"],
        "worry": ["担心", "忧虑", "担忧", "焦虑", "不安", "紧张"],
        "thought": ["思考", "想", "考虑", "琢磨", "思忖", "琢磨"],
        "sadness": ["悲伤", "难过", "伤心", "沮丧", "失落", "痛苦"],
        "fear": ["害怕", "恐惧", "畏惧", "担心", "不安", "惊慌"],
        "shock": ["震惊", "惊讶", "吃惊", "意外", "惊愕", "诧异"]
    }
    
    # Behavioral tendency modifiers
    TENDENCY_MODIFIERS = {
        "主导型": {"prefix": "[主导]", "tags": ["assertive", "confident"]},
        "压制型": {"prefix": "[压制]", "tags": ["dominant", "intense"]},
        "稳定型": {"prefix": "[稳定]", "tags": ["calm", "balanced"]},
        "被动型": {"prefix": "[被动]", "tags": ["reactive", "cautious"]},
        "脆弱型": {"prefix": "[脆弱]", "tags": ["vulnerable", "defensive"]}
    }
    
    def __init__(self, psychology_engine=None):
        """
        Initialize message formatter.
        
        Args:
            psychology_engine: PsychologyEngine instance for context
        """
        self.psychology_engine = psychology_engine
        self.narrative_mode = "first_person"
    
    def format_message(
        self,
        content: str,
        context: Optional[MessageContext] = None,
        psychology_output: Optional[Dict] = None
    ) -> FormattedMessage:
        """
        Format a message with Tiandao psychological context.
        
        Args:
            content: Raw message content
            context: Message context
            psychology_output: Pre-computed psychology output
            
        Returns:
            FormattedMessage instance
        """
        context = context or MessageContext(speaker_id="unknown")
        psychology_output = psychology_output or {}
        
        # Extract emotional state
        emotional_state = psychology_output.get("emotional_state", {})
        seven_emotions = self._derive_seven_emotions(emotional_state)
        
        # Apply emotional coloring
        colored_content = self._apply_emotional_coloring(content, seven_emotions)
        
        # Get behavioral tendency
        tendency = psychology_output.get("behavioral_tendency", "稳定型")
        tendency_info = self.TENDENCY_MODIFIERS.get(tendency, self.TENDENCY_MODIFIERS["稳定型"])
        
        # Generate Tiandao hints
        hints = self._generate_tiandao_hints(psychology_output, seven_emotions)
        
        # Apply author constraints if available
        if hasattr(self.psychology_engine, 'author_system'):
            colored_content = self._apply_author_constraints(
                colored_content, 
                tendency
            )
        
        return FormattedMessage(
            content=colored_content,
            emotional_coloring=seven_emotions,
            behavior_tags=tendency_info["tags"],
            tiandao_hints=hints,
            raw=False
        )
    
    def _derive_seven_emotions(self, emotional_state: Dict) -> Dict[str, float]:
        """Derive seven emotions from emotional state"""
        valence = emotional_state.get("valence", 0.0)
        arousal = emotional_state.get("arousal", 0.5)
        dominance = emotional_state.get("dominance", 0.5)
        
        # Map VAD to seven emotions (simplified)
        seven = {
            "joy": max(0, valence) * 0.8 + arousal * 0.2,
            "anger": max(0, -valence) * dominance if valence < 0 else 0,
            "worry": (1 - dominance) * 0.5 + (1 - arousal) * 0.3,
            "thought": (1 - arousal) * 0.6,
            "sadness": max(0, -valence) * (1 - dominance),
            "fear": (1 - dominance) * arousal * 0.5,
            "shock": arousal * abs(valence) * 0.3
        }
        
        # Normalize to 0-10 scale
        for emotion in seven:
            seven[emotion] = min(10, seven[emotion] * 10)
        
        return seven
    
    def _apply_emotional_coloring(
        self, 
        content: str, 
        seven_emotions: Dict[str, float]
    ) -> str:
        """Apply subtle emotional coloring to content"""
        if not content or all(v < 1 for v in seven_emotions.values()):
            return content
        
        # Determine dominant emotion
        dominant = max(seven_emotions.items(), key=lambda x: x[1])
        
        if dominant[1] < 2:
            return content
        
        # Add subtle emotional markers (optional)
        # In a full implementation, this could modify tone descriptors
        
        return content
    
    def _generate_tiandao_hints(
        self, 
        psychology_output: Dict,
        seven_emotions: Dict[str, float]
    ) -> Dict[str, Any]:
        """Generate Tiandao hints for the LLM"""
        hints = {
            "y_value": psychology_output.get("y_value", 50),
            "tendency": psychology_output.get("behavioral_tendency", "稳定型"),
            "overflow_warning": psychology_output.get("overflow_warning", False),
            "moral_adjustment": psychology_output.get("moral_adjustment", 0.0)
        }
        
        # Add dominant emotion if significant
        dominant = max(seven_emotions.items(), key=lambda x: x[1])
        if dominant[1] > 3:
            hints["dominant_emotion"] = dominant[0]
            hints["emotion_intensity"] = dominant[1]
        
        # Add triggered memories if any
        triggered = psychology_output.get("triggered_memories", [])
        if triggered:
            hints["triggered_memory_count"] = len(triggered)
        
        # Add active motivations
        motivations = psychology_output.get("active_motivations", [])
        if motivations:
            hints["active_motivations"] = motivations[:3]  # Top 3
        
        return hints
    
    def _apply_author_constraints(self, content: str, tendency: str) -> str:
        """Apply author constraints to content"""
        # No definition rule
        forbidden_patterns = [
            (r'是\s*(一个|一位)\s*.*?人', '展示而非说明'),
            (r'总是\s*', '避免绝对化描述'),
            (r'从不\s*', '避免绝对化描述'),
        ]
        
        return content
    
    def wrap_with_tiandao_context(
        self,
        content: str,
        psychology_output: Dict,
        context: MessageContext,
        include_system_hints: bool = True
    ) -> str:
        """
        Wrap content with full Tiandao context for LLM.
        
        Args:
            content: Message content
            psychology_output: Psychology calculation output
            context: Message context
            include_system_hints: Include system-level hints
            
        Returns:
            Wrapped content string
        """
        parts = []
        
        # Narrative mode prefix
        if context.narrative_mode == "third_person":
            parts.append(f"[第三人称视角]")
        elif context.narrative_mode == "limited":
            parts.append(f"[限制视角]")
        
        # Behavioral tendency
        tendency = psychology_output.get("behavioral_tendency", "稳定型")
        tendency_info = self.TENDENCY_MODIFIERS.get(tendency, self.TENDENCY_MODIFIERS["稳定型"])
        parts.append(f"[{tendency_info['prefix'].strip('[]')}]")
        
        # Emotional state
        emotional_state = psychology_output.get("emotional_state", {})
        valence = emotional_state.get("valence", 0)
        if valence > 0.3:
            parts.append("[情绪: 偏正面]")
        elif valence < -0.3:
            parts.append("[情绪: 偏负面]")
        
        # Overflow warning
        if psychology_output.get("overflow_warning"):
            parts.append("[注意: 情绪极值状态]")
        
        # System hints for LLM
        if include_system_hints:
            hints = self._generate_tiandao_hints(
                psychology_output,
                self._derive_seven_emotions(emotional_state)
            )
            
            # Format as visible hints
            hint_parts = [f"Y={hints['y_value']}"]
            if "dominant_emotion" in hints:
                hint_parts.append(f"情绪:{hints['dominant_emotion']}")
            if hints.get("triggered_memory_count", 0) > 0:
                hint_parts.append(f"触发记忆:{hints['triggered_memory_count']}")
            
            parts.append(f"[系统提示: {', '.join(hint_parts)}]")
        
        # Combine
        prefix = " ".join(parts)
        return f"{prefix}\n\n{content}"
    
    def extract_tiandao_tags(self, text: str) -> List[str]:
        """
        Extract Tiandao system tags from text.
        
        Useful for parsing responses that include system hints.
        """
        import re
        
        tags = []
        
        # Extract Y value
        y_match = re.search(r'Y\s*[=:]\s*(\d+)', text)
        if y_match:
            tags.append(f"y_value:{y_match.group(1)}")
        
        # Extract emotional tags
        emotion_patterns = {
            "joy": r'情绪[:：]?.*?(开心|高兴|快乐|喜悦)',
            "anger": r'情绪[:：]?.*?(愤怒|生气|恼火)',
            "sadness": r'情绪[:：]?.*?(悲伤|难过|伤心)',
            "fear": r'情绪[:：]?.*?(害怕|恐惧|担心)',
            "shock": r'情绪[:：]?.*?(震惊|惊讶|意外)'
        }
        
        for emotion, pattern in emotion_patterns.items():
            if re.search(pattern, text):
                tags.append(f"emotion:{emotion}")
        
        # Extract tendency
        tendency_pattern = r'\[(主导|压制|稳定|被动|脆弱)型\]'
        tendency_match = re.search(tendency_pattern, text)
        if tendency_match:
            tags.append(f"tendency:{tendency_match.group(1)}")
        
        return tags
    
    def create_response_context(
        self,
        speaker_profile: Dict,
        situation: str,
        recent_history: List[Dict]
    ) -> Dict:
        """
        Create context for generating a response.
        
        Args:
            speaker_profile: Speaker's character profile
            situation: Current situation
            recent_history: Recent message history
            
        Returns:
            Context dictionary for response generation
        """
        context = {
            "situation": situation,
            "speaker": {
                "name": speaker_profile.get("info", {}).get("name", "Unknown"),
                "mbti": speaker_profile.get("info", {}).get("mbti_type", "INTJ"),
                "base_y": speaker_profile.get("info", {}).get("base_y", 50)
            },
            "recent_emotions": [],
            "suggested_tone": "neutral"
        }
        
        # Analyze recent history for emotional continuity
        for msg in recent_history[-3:]:
            if "emotional_state" in msg:
                context["recent_emotions"].append(msg["emotional_state"])
        
        # Determine suggested tone
        if context["recent_emotions"]:
            avg_valence = sum(e.get("valence", 0) for e in context["recent_emotions"]) / len(context["recent_emotions"])
            if avg_valence > 0.3:
                context["suggested_tone"] = "positive"
            elif avg_valence < -0.3:
                context["suggested_tone"] = "negative"
        
        return context


def format_with_tiandao_context(
    content: str,
    psychology_output: Dict,
    context: MessageContext
) -> str:
    """
    Convenience function to format a message with Tiandao context.
    
    Args:
        content: Message content
        psychology_output: Psychology calculation output
        context: Message context
        
    Returns:
        Formatted message string
    """
    formatter = MessageFormatter()
    return formatter.wrap_with_tiandao_context(content, psychology_output, context)
