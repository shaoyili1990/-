"""
Tests for Server Routes and Health Endpoints
"""

import pytest
import json


class TestHealthCheck:
    """Test health check endpoint"""
    
    def test_health_check(self, client):
        """Test health check returns healthy status"""
        response = client.get('/health')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['status'] == 'healthy'
        assert 'timestamp' in data
        assert 'version' in data
        assert 'services' in data
    
    def test_health_check_services(self, client):
        """Test health check includes service status"""
        response = client.get('/health')
        
        data = json.loads(response.data)
        assert data['services']['psychology'] == 'operational'
        assert data['services']['character'] == 'operational'
        assert data['services']['formatter'] == 'operational'


class TestAPIInfo:
    """Test API information endpoints"""
    
    def test_api_info_v1(self, client):
        """Test API v1 info endpoint"""
        response = client.get('/api/v1')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['name'] == 'SillyTavern Tiandao Backend'
        assert 'version' in data
        assert 'endpoints' in data
    
    def test_api_info_root(self, client):
        """Test API root info endpoint"""
        response = client.get('/api')
        
        assert response.status_code == 200


class TestSystemEndpoints:
    """Test system configuration endpoints"""
    
    def test_get_system_config(self, client):
        """Test getting system config"""
        response = client.get('/api/v1/system/config')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'version' in data['data']
        assert 'max_characters' in data['data']
        assert 'debug_mode' in data['data']
    
    def test_get_system_stats(self, client):
        """Test getting system stats"""
        response = client.get('/api/v1/system/stats')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'active_engines' in data['data']
        assert 'stored_characters' in data['data']
        assert 'timestamp' in data['data']


class TestCORS:
    """Test CORS configuration"""
    
    def test_cors_headers_present(self, client):
        """Test CORS headers are present"""
        response = client.get('/health')
        
        # Check for CORS headers (may vary by implementation)
        assert response.status_code == 200


class TestErrorHandlers:
    """Test error handlers"""
    
    def test_404_error(self, client):
        """Test 404 error handling"""
        response = client.get('/nonexistent/endpoint')
        
        assert response.status_code == 404
        data = json.loads(response.data)
        assert data['success'] is False
        assert 'error' in data
    
    def test_405_error(self, client):
        """Test 405 error handling"""
        response = client.patch('/health')
        
        assert response.status_code == 405
    
    def test_500_error(self, client):
        """Test 500 error handling"""
        # This would require triggering an actual error
        # For now, just verify the endpoint exists
        response = client.get('/health')
        assert response.status_code == 200


class TestRequestValidation:
    """Test request validation"""
    
    def test_json_content_type(self, client):
        """Test JSON content type handling"""
        response = client.post(
            '/api/v1/psychology/calculate',
            data='not json',
            content_type='application/json'
        )
        
        # Flask will return 400 for invalid JSON when using get_json()
        assert response.status_code == 400
    
    def test_large_request_rejected(self, client):
        """Test large requests validation"""
        large_data = {'situation': 'x' * 20000}
        
        response = client.post(
            '/api/v1/psychology/calculate',
            json=large_data
        )
        
        # Should return 422 for validation error (too long)
        assert response.status_code == 422
