"""
Tests for Utility Functions
"""

import pytest
from datetime import datetime


class TestResponseUtils:
    """Test response utility functions"""
    
    def test_success_response(self, app):
        """Test success response creation"""
        from utils.responses import success_response
        
        with app.app_context():
            response, status = success_response(
                data={'key': 'value'},
                message='Test success'
            )
            
            assert status == 200
            data = response.get_json()
            assert data['success'] is True
            assert data['message'] == 'Test success'
            assert data['data']['key'] == 'value'
    
    def test_error_response(self, app):
        """Test error response creation"""
        from utils.responses import error_response
        
        with app.app_context():
            response, status = error_response(
                message='Test error',
                error_code='TEST_ERROR'
            )
            
            assert status == 400
            data = response.get_json()
            assert data['success'] is False
            assert data['error']['message'] == 'Test error'
            assert data['error']['code'] == 'TEST_ERROR'
    
    def test_paginated_response(self, app):
        """Test paginated response"""
        from utils.responses import paginated_response
        
        with app.app_context():
            response, status = paginated_response(
                items=[1, 2, 3],
                total=10,
                page=1,
                per_page=3
            )
            
            assert status == 200
            data = response.get_json()
            assert data['pagination']['total'] == 10
            assert data['pagination']['total_pages'] == 4
            assert data['pagination']['has_next'] is True


class TestValidators:
    """Test validation functions"""
    
    def test_validate_character_data_valid(self):
        """Test valid character data"""
        from utils.validators import validate_character_data
        
        valid, errors = validate_character_data({
            'name': 'Valid Character',
            'base_y': 50,
            'mbti_type': 'INTJ',
            'tags': ['test']
        })
        
        assert valid is True
        assert len(errors) == 0
    
    def test_validate_character_data_invalid(self):
        """Test invalid character data"""
        from utils.validators import validate_character_data
        
        valid, errors = validate_character_data({
            'name': '',  # Empty name
            'base_y': 150,  # Invalid Y
            'mbti_type': 'INVALID'  # Invalid MBTI
        })
        
        assert valid is False
        assert len(errors) > 0
    
    def test_validate_character_data_no_name(self):
        """Test missing name"""
        from utils.validators import validate_character_data
        
        valid, errors = validate_character_data({})
        
        assert valid is False
        assert 'name' in errors
    
    def test_validate_memory_data_valid(self):
        """Test valid memory data"""
        from utils.validators import validate_memory_data
        
        valid, errors = validate_memory_data({
            'content': 'Valid memory content',
            'memory_type': 'episodic',
            'emotional_intensity': 0.5
        })
        
        assert valid is True
    
    def test_validate_memory_data_invalid(self):
        """Test invalid memory data"""
        from utils.validators import validate_memory_data
        
        valid, errors = validate_memory_data({
            'content': '',  # Empty
            'memory_type': 'invalid_type',
            'emotional_intensity': 1.5  # Out of range
        })
        
        assert valid is False
    
    def test_validate_situation(self):
        """Test situation validation"""
        from utils.validators import validate_situation
        
        valid, error = validate_situation("Valid situation")
        assert valid is True
        assert error is None
        
        valid, error = validate_situation("")
        assert valid is False
        
        valid, error = validate_situation("x" * 15000)
        assert valid is False
    
    def test_validate_uuid(self):
        """Test UUID validation"""
        from utils.validators import validate_uuid
        
        assert validate_uuid('12345678') is True
        assert validate_uuid('12345678-abcd') is False  # Wrong format
        assert validate_uuid('not-a-uuid') is False


class TestFormatters:
    """Test formatting functions"""
    
    def test_format_datetime_iso(self):
        """Test datetime formatting"""
        from utils.formatters import format_datetime
        
        dt = datetime(2024, 1, 15, 12, 30, 0)
        result = format_datetime(dt)
        
        assert '2024-01-15' in result
        assert result.endswith('Z')
    
    def test_format_datetime_none(self):
        """Test None datetime"""
        from utils.formatters import format_datetime
        
        result = format_datetime(None)
        assert result is None
    
    def test_sanitize_string(self):
        """Test string sanitization"""
        from utils.formatters import sanitize_string
        
        # Normal string
        result = sanitize_string("Normal text")
        assert result == "Normal text"
        
        # With null bytes
        result = sanitize_string("Text\x00with null")
        assert '\x00' not in result
        
        # Too long
        long_text = "x" * 20000
        result = sanitize_string(long_text, max_length=100)
        assert len(result) == 100
