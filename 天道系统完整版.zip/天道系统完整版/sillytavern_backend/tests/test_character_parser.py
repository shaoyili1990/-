"""
Tests for Character Card Parser
"""

import pytest
import json


class TestCharacterCardParser:
    """Test character card parsing"""
    
    def test_parse_sillytavern_format(self):
        """Test parsing SillyTavern format"""
        from character_manager import CharacterCardParser
        
        parser = CharacterCardParser()
        
        card_data = {
            "spec": {
                "name": "Test Character"
            },
            "description": "A test character",
            "char persona": "[理性][内耗][独立]"
        }
        
        parsed = parser.parse_json(card_data)
        
        assert parsed.name == "Test Character"
        assert "A test character" in parsed.description
    
    def test_parse_tavernai_v2_format(self):
        """Test parsing TavernAI v2 format"""
        from character_manager import CharacterCardParser
        
        parser = CharacterCardParser()
        
        card_data = {
            "data": {
                "name": "TavernAI Character",
                "description": "TavernAI format test",
                "tags": ["INTJ", "理性"]
            }
        }
        
        parsed = parser.parse_json(card_data)
        
        assert parsed.name == "TavernAI Character"
    
    def test_parse_legacy_format(self):
        """Test parsing legacy format"""
        from character_manager import CharacterCardParser
        
        parser = CharacterCardParser()
        
        card_data = {
            "name": "Legacy Character",
            "description": "Legacy format test",
            "personality": "Some personality"
        }
        
        parsed = parser.parse_json(card_data)
        
        assert parsed.name == "Legacy Character"
    
    def test_mbti_inference(self):
        """Test MBTI inference from tags"""
        from character_manager import CharacterCardParser
        
        parser = CharacterCardParser()
        
        mbti, confidence = parser._infer_mbti(['理性', '独立', '完美主义'])
        
        assert mbti == 'INTJ'
        assert confidence > 0
    
    def test_trauma_detection(self):
        """Test trauma level detection"""
        from character_manager import CharacterCardParser
        
        parser = CharacterCardParser()
        
        trauma = parser._detect_trauma(
            "经历过创伤事件",
            "有PTSD症状"
        )
        
        assert trauma > 0
    
    def test_to_character_info(self):
        """Test conversion to CharacterInfo"""
        from character_manager import CharacterCardParser
        
        parser = CharacterCardParser()
        
        card_data = {
            "spec": {"name": "Convert Test"},
            "description": "Conversion test"
        }
        
        parsed = parser.parse_json(card_data)
        info = parser.to_character_info(parsed)
        
        assert info.name == "Convert Test"
        assert info.base_y > 0
    
    def test_to_tiandao_format(self):
        """Test conversion to Tiandao format"""
        from character_manager import CharacterCardParser
        
        parser = CharacterCardParser()
        
        card_data = {
            "spec": {"name": "Tiandao Test"},
            "description": "Test"
        }
        
        parsed = parser.parse_json(card_data)
        result = parser.to_tiandao_format(parsed)
        
        assert 'character_id' in result
        assert 'mbti_profile' in result
        assert 'parsing_metadata' in result
    
    def test_parse_json_string(self):
        """Test parsing JSON string"""
        from character_manager import CharacterCardParser
        
        parser = CharacterCardParser()
        
        json_str = '{"spec": {"name": "JSON String Test"}}'
        parsed = parser.parse_json(json_str)
        
        assert parsed.name == "JSON String Test"


class TestParseConvenienceFunction:
    """Test convenience function"""
    
    def test_parse_character_card(self):
        """Test convenience function"""
        from character_manager import parse_character_card
        
        card_data = {
            "spec": {"name": "Convenience Test"}
        }
        
        parsed = parse_character_card(card_data)
        
        assert parsed.name == "Convenience Test"
    
    def test_parse_with_dict(self):
        """Test parsing dictionary"""
        from character_manager import parse_character_card
        
        parsed = parse_character_card({"name": "Dict Test"})
        
        assert parsed.name == "Dict Test"
