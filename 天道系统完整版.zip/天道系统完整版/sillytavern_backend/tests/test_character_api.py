"""
Tests for Character API Endpoints
"""

import pytest
import json
import uuid


class TestCharacterList:
    """Test character list endpoint"""
    
    def test_list_characters_empty(self, client):
        """Test listing when no characters exist"""
        response = client.get('/api/v1/characters')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['success'] is True
        assert 'data' in data
    
    def test_list_characters_with_data(self, client, sample_character_data):
        """Test listing with existing characters"""
        # Create a character first
        client.post('/api/v1/characters', json=sample_character_data)
        
        response = client.get('/api/v1/characters')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert len(data['data']) >= 1
    
    def test_list_characters_pagination(self, client, sample_character_data):
        """Test pagination"""
        # Create multiple characters
        for i in range(5):
            data = sample_character_data.copy()
            data['name'] = f'Character {i}'
            client.post('/api/v1/characters', json=data)
        
        response = client.get('/api/v1/characters?page=1&per_page=2')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['pagination']['per_page'] == 2
    
    def test_list_characters_search(self, client, sample_character_data):
        """Test search functionality"""
        client.post('/api/v1/characters', json=sample_character_data)
        
        response = client.get('/api/v1/characters?search=测试')
        
        assert response.status_code == 200


class TestCharacterCRUD:
    """Test character CRUD operations"""
    
    def test_create_character(self, client, sample_character_data):
        """Test creating a character"""
        response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['success'] is True
        assert data['data']['info']['name'] == sample_character_data['name']
    
    def test_create_character_minimal(self, client):
        """Test creating with minimal data"""
        response = client.post(
            '/api/v1/characters',
            json={'name': 'Minimal Char'}
        )
        
        assert response.status_code == 201
    
    def test_create_character_no_name(self, client):
        """Test creating without name fails"""
        response = client.post(
            '/api/v1/characters',
            json={'description': 'No name'}
        )
        
        assert response.status_code == 422
    
    def test_create_character_invalid_mbti(self, client):
        """Test creating with invalid MBTI"""
        response = client.post(
            '/api/v1/characters',
            json={'name': 'Test', 'mbti_type': 'INVALID'}
        )
        
        assert response.status_code == 422
    
    def test_create_character_invalid_y(self, client):
        """Test creating with invalid Y value"""
        response = client.post(
            '/api/v1/characters',
            json={'name': 'Test', 'base_y': 150}
        )
        
        assert response.status_code == 422
    
    def test_get_character(self, client, sample_character_data):
        """Test getting a character"""
        # Create
        create_response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        created = json.loads(create_response.data)
        char_id = created['data']['info']['id']
        
        # Get
        response = client.get(f'/api/v1/characters/{char_id}')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['data']['info']['name'] == sample_character_data['name']
    
    def test_get_character_not_found(self, client):
        """Test getting non-existent character"""
        response = client.get('/api/v1/characters/nonexistent')
        
        assert response.status_code == 404
    
    def test_update_character(self, client, sample_character_data):
        """Test updating a character"""
        # Create
        create_response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        created = json.loads(create_response.data)
        char_id = created['data']['info']['id']
        
        # Update
        response = client.put(
            f'/api/v1/characters/{char_id}',
            json={'name': 'Updated Name', 'base_y': 60}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data['data']['info']['name'] == 'Updated Name'
        assert data['data']['info']['base_y'] == 60
    
    def test_delete_character(self, client, sample_character_data):
        """Test deleting a character"""
        # Create
        create_response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        created = json.loads(create_response.data)
        char_id = created['data']['info']['id']
        
        # Delete
        response = client.delete(f'/api/v1/characters/{char_id}')
        
        assert response.status_code == 200
        
        # Verify deleted
        get_response = client.get(f'/api/v1/characters/{char_id}')
        assert get_response.status_code == 404


class TestCharacterMemories:
    """Test character memory endpoints"""
    
    def test_add_character_memory(self, client, sample_character_data, sample_memory_data):
        """Test adding memory to character"""
        # Create character
        create_response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        created = json.loads(create_response.data)
        char_id = created['data']['info']['id']
        
        # Add memory
        response = client.post(
            f'/api/v1/characters/{char_id}/memories',
            json=sample_memory_data
        )
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert 'memory_id' in data['data']
    
    def test_get_character_memories(self, client, sample_character_data):
        """Test getting character memories"""
        # Create character
        create_response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        created = json.loads(create_response.data)
        char_id = created['data']['info']['id']
        
        response = client.get(f'/api/v1/characters/{char_id}/memories')
        
        assert response.status_code == 200
    
    def test_retrieve_character_memories(self, client, sample_character_data, sample_memory_data):
        """Test retrieving relevant memories"""
        # Create character
        create_response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        created = json.loads(create_response.data)
        char_id = created['data']['info']['id']
        
        # Add memory
        client.post(
            f'/api/v1/characters/{char_id}/memories',
            json=sample_memory_data
        )
        
        # Retrieve
        response = client.post(
            f'/api/v1/characters/{char_id}/memories/retrieve',
            json={'query': '重要'}
        )
        
        assert response.status_code == 200


class TestCharacterYValue:
    """Test character Y-value endpoints"""
    
    def test_get_character_y_value(self, client, sample_character_data):
        """Test getting character Y-value"""
        # Create character
        create_response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        created = json.loads(create_response.data)
        char_id = created['data']['info']['id']
        
        response = client.get(f'/api/v1/characters/{char_id}/y-value')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'y_value' in data['data']
    
    def test_trigger_character_y_event(self, client, sample_character_data):
        """Test triggering Y event on character"""
        # Create character
        create_response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        created = json.loads(create_response.data)
        char_id = created['data']['info']['id']
        
        response = client.post(
            f'/api/v1/characters/{char_id}/y-value/trigger',
            json={'event_type': 'breakthrough', 'value': 80}
        )
        
        assert response.status_code == 200


class TestCharacterPsychology:
    """Test character psychology calculation"""
    
    def test_calculate_character_response(self, client, sample_character_data, sample_situation):
        """Test calculating character response"""
        # Create character
        create_response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        created = json.loads(create_response.data)
        char_id = created['data']['info']['id']
        
        response = client.post(
            f'/api/v1/characters/{char_id}/calculate',
            json={'situation': sample_situation}
        )
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'response' in data['data']
    
    def test_check_character_ptsd(self, client, sample_character_data):
        """Test PTSD check"""
        # Create character
        create_response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        created = json.loads(create_response.data)
        char_id = created['data']['info']['id']
        
        response = client.post(
            f'/api/v1/characters/{char_id}/ptsd',
            json={'event': '战斗'}
        )
        
        assert response.status_code == 200


class TestCharacterInstinct:
    """Test character instinct activation"""
    
    def test_activate_character_instinct(self, client, sample_character_data):
        """Test activating instinct"""
        # Create character
        create_response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        created = json.loads(create_response.data)
        char_id = created['data']['info']['id']
        
        response = client.post(
            f'/api/v1/characters/{char_id}/activate-instinct',
            json={'instinct': 'survival', 'intensity_modifier': 1.2}
        )
        
        assert response.status_code == 200
    
    def test_activate_invalid_instinct(self, client, sample_character_data):
        """Test activating invalid instinct"""
        # Create character
        create_response = client.post(
            '/api/v1/characters',
            json=sample_character_data
        )
        created = json.loads(create_response.data)
        char_id = created['data']['info']['id']
        
        response = client.post(
            f'/api/v1/characters/{char_id}/activate-instinct',
            json={'instinct': 'invalid'}
        )
        
        assert response.status_code == 422


class TestBulkOperations:
    """Test bulk operations"""
    
    def test_bulk_create_characters(self, client):
        """Test bulk character creation"""
        characters = [
            {'name': 'Bulk Char 1', 'base_y': 50},
            {'name': 'Bulk Char 2', 'base_y': 60},
            {'name': 'Bulk Char 3', 'base_y': 70}
        ]
        
        response = client.post(
            '/api/v1/characters/bulk',
            json={'characters': characters}
        )
        
        assert response.status_code == 201
        data = json.loads(response.data)
        assert data['data']['total_created'] == 3
        assert data['data']['total_errors'] == 0


class TestImportExport:
    """Test import functionality"""
    
    def test_import_character_card(self, client):
        """Test importing a character card"""
        character_card = {
            "spec": {
                "name": "Imported Character",
                "description": "A character imported from card"
            },
            "char_persona": "[INTJ][理性][独立]"
        }
        
        response = client.post(
            '/api/v1/characters/import',
            json={'character_card': character_card}
        )
        
        assert response.status_code == 201


class TestCharacterStats:
    """Test character statistics"""
    
    def test_get_character_stats(self, client, sample_character_data):
        """Test getting character stats"""
        # Create some characters
        client.post('/api/v1/characters', json=sample_character_data)
        
        response = client.get('/api/v1/characters/stats')
        
        assert response.status_code == 200
        data = json.loads(response.data)
        assert 'total_characters' in data['data']
        assert 'mbti_distribution' in data['data']
