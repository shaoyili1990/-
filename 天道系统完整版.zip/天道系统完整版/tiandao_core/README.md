# 天道系统 (Tiandao System)

Python 核心包 - 角色心理系统模拟

## 概述

天道系统是一个完整的角色心理模拟框架，包含：

- **Y值系统** - 主观意识凝练强度
- **MBTI系统** - 16型人格权重
- **记忆系统** - 5型记忆与PTSD机制
- **动机系统** - 7本能4层级
- **作者约束系统** - 创作方法论
- **心理学引擎** - 综合计算

## 核心公式

### 系统架构

```
系统 = 先天本能（水） + 后天参数（容器） + 实时计算（势）
```

### 天道原则

```
天道 = 损有余而补不足
包含：
1. 盈满则亏
2. 过犹不及
3. 动态流转
4. 并列共担
```

### Y值核心

```
Y = 人物「主观意识凝练强度」
- 执行力：Y越高，意识越坚定
- 影响力：Y越高，气场越强
- 被影响力：Y越低，越容易被操控
```

## 安装

```bash
pip install -e .
```

## 快速开始

### 创建角色

```python
from tiandao.core import CharacterProfile

profile = CharacterProfile.create(
    character_id="char_001",
    name="枫",
    base_y=70,
    mbti_type="INTJ"
)
```

### 计算心理反应

```python
result = profile.calculate_response(
    situation="战友牺牲了",
    interaction_y=65
)
print(result)
```

### 添加记忆

```python
from tiandao.core.memory import MemoryType

profile.add_memory(
    content="创伤记忆内容",
    memory_type=MemoryType.EPISODIC,
    emotional_intensity=0.9,
    is_traumatic=True,
    trauma_level=0.8
)
```

### 检查PTSD

```python
result = profile.check_ptsd("类似创伤的场景")
print(f"PTSD触发: {result['triggered']}")
```

## CLI 使用

```bash
# 创建角色
python -m tiandao.cli create --name "枫" --mbti INTJ --y 70

# 计算反应
python -m tiandao.cli calculate --character "枫" --situation "战友牺牲"

# 记忆管理
python -m tiandao.cli memory add --character "枫" --content "创伤" --traumatic

# 显示画像
python -m tiandao.cli profile --character "枫" --format json

# Y值系统
python -m tiandao.cli yvalue status
python -m tiandao.cli yvalue breakthrough --attacker 80 --defender 50

# MBTI系统
python -m tiandao.cli mbti profile --type INTJ
python -m tiandao.cli mbti from_tags --tags "理性,内耗,独立"
```

## 系统详情

### Y值系统

- 击穿阈值规则
- 触发/补偿/回弹机制
- PTSD扳机
- 重大事件触发

### MBTI系统

- 16型完整权重
- Big Five映射
- Y值基线计算
- 反应风格分析

### 记忆系统

- 5型记忆（情景/程序/语义/情绪/感觉）
- PTSD机制
- 记忆强度与衰减
- 异常记忆惩罚

### 动机系统

- 7本能（生存/群体/权力/意义/愉悦/安全/成长）
- 4层级（表层/心理/本能/核心）
- 动机链传导
- 冲突检测与解决

### 作者约束

- AI思维限制器
- 群像创作思维
- 冲突变量库
- 中医开方思维

## 运行测试

```bash
pytest tests/ -v
```

## 项目结构

```
tiandao_core/
├── tiandao/
│   ├── __init__.py
│   ├── cli.py
│   └── core/
│       ├── __init__.py
│       ├── y_value.py      # Y值系统
│       ├── mbti.py         # MBTI系统
│       ├── memory.py       # 记忆系统
│       ├── motivation.py   # 动机系统
│       ├── author.py       # 作者约束
│       ├── psychology.py   # 心理学引擎
│       └── profile.py      # 角色画像
├── tests/
│   └── test_integration.py
├── README.md
└── setup.py
```

## License

MIT
